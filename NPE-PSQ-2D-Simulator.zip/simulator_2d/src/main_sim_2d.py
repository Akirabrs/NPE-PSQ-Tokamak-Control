"""
Simulador NPE-PSQ 2D Completo e Integrado

Este script integra geometria, solver ADI e controle avançado para
uma simulação completa de um tokamak em 2D.
"""

import numpy as np
import time
import sys
import os

# Adicionar diretórios ao path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'geometry'))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'transport'))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'control'))

from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D
from geometry.differential_operators_2d import DifferentialOperators2D
from transport.solver_adi_2d import SolverADI2D
from control.npe_psq_2d import NPE_PSQ_Controller_2D
from plasma_state_2d import PlasmaState2D


class TokamakSimulator2D:
    """
    Simulador integrado NPE-PSQ 2D.
    """
    
    def __init__(self, n_rho=50, n_theta=32):
        # 1. Inicializar Geometria e Grade
        self.geom = TokamakGeometry2D()
        self.grid = Grid2D(n_rho=n_rho, n_theta=n_theta, packing_factor=1.5)
        self.ops = DifferentialOperators2D(self.geom, self.grid)
        
        # 2. Inicializar Estado do Plasma
        self.state = PlasmaState2D(self.geom, self.grid)
        self.state.initialize_profiles(
            T_e_center=1.0, 
            T_i_center=1.0, 
            n_e_center=5.0,
            asymmetry=0.1
        )
        self.state.Ip = 10.0 # MA
        self.state.Z_pos = 0.02 # 2 cm de erro inicial
        
        # 3. Inicializar Solver e Controlador
        self.solver = SolverADI2D(self.geom, self.grid, self.ops)
        self.controller = NPE_PSQ_Controller_2D()
        
        # 4. Configurações de Transporte
        self.chi_base = 1.0 # m²/s
        
    def run_simulation(self, duration=0.5, dt=0.001):
        """
        Executa a simulação por uma duração especificada.
        """
        print("=" * 80)
        print(f"INICIANDO SIMULAÇÃO NPE-PSQ 2D (Duração: {duration}s, dt: {dt}s)")
        print("=" * 80)
        
        n_steps = int(duration / dt)
        start_time = time.time()
        
        print(f"{'Tempo [s]':<10} {'T_e_avg':<10} {'Z [mm]':<10} {'P_tot [MW]':<10} {'W [MJ]':<10}")
        print("-" * 60)
        
        for step in range(n_steps):
            # A. Controlador: Calcular Atuação
            act = self.controller.compute_actuation(self.state, dt)
            
            # B. Solver: Evolução do Transporte (T_e)
            # Simplificação: T_i segue T_e para este demo
            # Fonte de aquecimento 2D (distribuída)
            source_2d = np.ones_like(self.state.T_e) * (act['P_total'] / self.geom.volume)
            
            # Coeficiente de transporte (Bohm-like: aumenta com a temperatura)
            chi_2d = self.chi_base * (1.0 + self.state.T_e / 5.0)
            
            self.state.T_e = self.solver.step(
                self.state.T_e, self.state.n_e, chi_2d, source_2d, dt
            )
            self.state.T_i = self.state.T_e.copy()
            
            # C. Controlador: Atualizar Dinâmica Vertical
            self.controller.update_state(self.state, act, dt)
            
            # D. Atualizar Tempo
            self.state.time += dt
            
            # E. Diagnóstico Ocasional
            if step % 50 == 0:
                signals = self.controller.diagnostics.get_control_signals(self.state)
                print(f"{self.state.time:<10.3f} {signals['T_e_avg']:<10.2f} "
                      f"{signals['z_pos']*1000:<10.2f} {act['P_total']:<10.1f} "
                      f"{signals['W_total']:<10.1f}")
                
        end_time = time.time()
        print("-" * 60)
        print(f"Simulação concluída em {end_time - start_time:.2f} segundos.")
        print(f"Estado Final: {self.state}")
        print("=" * 80)
        
        return self.state


if __name__ == "__main__":
    sim = TokamakSimulator2D()
    final_state = sim.run_simulation(duration=0.5, dt=0.002)
