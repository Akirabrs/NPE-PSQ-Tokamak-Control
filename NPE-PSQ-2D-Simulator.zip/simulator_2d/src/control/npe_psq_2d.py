"""
Controlador NPE-PSQ 2D para o Simulador de Tokamak

Este módulo implementa a arquitetura de controle avançada adaptada
para o modelo 2D, integrando controle de perfis e estabilização vertical.
"""

import numpy as np
from typing import Dict, List, Tuple
import sys
sys.path.append('..')

from plasma_state_2d import PlasmaState2D
from control.vertical_control_2d import VerticalController2D, Diagnostics2D


class NPE_PSQ_Controller_2D:
    """
    Controlador NPE-PSQ (Neural Predictive Equilibrium - Plasma State Quantizer)
    adaptado para o simulador 2D.
    """
    
    def __init__(self):
        # Controladores internos
        self.vertical_ctrl = VerticalController2D()
        self.diagnostics = Diagnostics2D()
        
        # Alvos de controle
        self.targets = {
            'T_e_avg': 10.0,    # [keV]
            'n_e_avg': 8.0,     # [10²⁰ m⁻³]
            'beta_N': 2.5,      # Beta normalizado
            'z_pos': 0.0        # [m]
        }
        
        # Limites dos atuadores [MW]
        self.limits = {
            'P_ECRH': (0.0, 50.0),
            'P_ICRH': (0.0, 50.0),
            'P_NBI': (0.0, 100.0)
        }
        
        # Ganhos de controle de potência
        self.Kp_power = 5.0
        self.Ki_power = 0.5
        self.power_integral = 0.0
        
    def compute_actuation(self, state: PlasmaState2D, dt: float) -> Dict[str, float]:
        """
        Calcula os sinais de atuação baseados no estado 2D.
        
        Args:
            state: Estado atual do plasma 2D
            dt: Passo de tempo
            
        Returns:
            Dicionário com potências e forças de controle
        """
        # 1. Obter diagnósticos do estado 2D
        signals = self.diagnostics.get_control_signals(state)
        
        # 2. Controle de Temperatura (Potência Total)
        error_T = self.targets['T_e_avg'] - signals['T_e_avg']
        self.power_integral += error_T * dt
        
        P_total = self.Kp_power * error_T + self.Ki_power * self.power_integral
        P_total = np.clip(P_total, 0.0, 200.0)
        
        # Estratégia de divisão de potência (NPE-PSQ)
        # ECRH para o centro, ICRH para íons, NBI para ambos
        P_ECRH = np.clip(P_total * 0.3, *self.limits['P_ECRH'])
        P_ICRH = np.clip(P_total * 0.3, *self.limits['P_ICRH'])
        P_NBI = np.clip(P_total * 0.4, *self.limits['P_NBI'])
        
        # 3. Controle Vertical
        f_z = self.vertical_ctrl.compute_control_force(state.Z_pos, state.Z_vel, dt)
        
        # 4. Ajuste de Assimetria (Funcionalidade NPE-PSQ 2D)
        # Se a assimetria in-out for muito alta, ajustamos a deposição de ECRH
        # (Simulado aqui ajustando a potência relativa)
        if signals['A_IO'] > 0.1:
            P_ECRH *= 0.9 # Reduz potência no lado externo para equilibrar
            
        return {
            'P_ECRH': P_ECRH,
            'P_ICRH': P_ICRH,
            'P_NBI': P_NBI,
            'F_z': f_z,
            'P_total': P_ECRH + P_ICRH + P_NBI
        }

    def update_state(self, state: PlasmaState2D, actuation: Dict[str, float], dt: float):
        """
        Atualiza as componentes de controle do estado (ex: posição vertical).
        Nota: O transporte 2D é atualizado pelo SolverADI2D.
        """
        self.vertical_ctrl.update_dynamics(state, actuation['F_z'], dt)
        # state.time += dt # Removido para evitar incremento duplo se o solver também incrementar


if __name__ == "__main__":
    # Teste do controlador NPE-PSQ 2D
    print("=" * 80)
    print("TESTE DO CONTROLADOR NPE-PSQ 2D")
    print("=" * 80)
    
    from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D
    
    geom = TokamakGeometry2D()
    grid = Grid2D(n_rho=20, n_theta=16)
    state = PlasmaState2D(geom, grid)
    state.initialize_profiles(T_e_center=5.0, n_e_center=5.0)
    state.z_pos = 0.05 # 5 cm de erro vertical
    
    controller = NPE_PSQ_Controller_2D()
    
    print(f"{'Tempo [s]':<10} {'T_e_avg':<10} {'Z [mm]':<10} {'P_total':<10}")
    print("-" * 50)
    
    dt = 0.01
    for i in range(50):
        act = controller.compute_actuation(state, dt)
        controller.update_state(state, act, dt)
        
        # Simular aquecimento simplificado para o teste
        T_e_avg = state.compute_volume_average(state.T_e)
        state.T_e += (act['P_total'] / 100.0) * dt # Aquecimento linear fake
        
        if i % 10 == 0:
            print(f"{state.time:<10.2f} {T_e_avg:<10.2f} {state.z_pos*1000:<10.2f} {act['P_total']:<10.1f}")
            
    print("-" * 50)
    print("Teste concluído com sucesso! ✅")
    print("\n" + "=" * 80)
