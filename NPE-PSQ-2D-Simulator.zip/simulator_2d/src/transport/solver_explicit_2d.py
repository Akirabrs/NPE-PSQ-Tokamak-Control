"""
Solver Explícito 2D para o Simulador NPE-PSQ

Este módulo implementa um solver explícito simples para validar as
equações de transporte 2D antes de usar o ADI.
"""

import numpy as np
import sys
sys.path.append('..')

from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D
from geometry.differential_operators_2d import DifferentialOperators2D


class SolverExplicit2D:
    """
    Solver explícito para as equações de transporte 2D.
    ∂f/∂t = ∇·(χ ∇f) + S
    """
    
    def __init__(self, geometry: TokamakGeometry2D, grid: Grid2D, operators: DifferentialOperators2D):
        self.geometry = geometry
        self.grid = grid
        self.ops = operators
        
    def step(self, 
             field: np.ndarray, 
             density: np.ndarray,
             chi: np.ndarray, 
             source: np.ndarray, 
             dt: float,
             f_edge: float = 0.01,
             is_density: bool = False) -> np.ndarray:
        
        # 1. Calcular termo de difusão: ∇·(χ ∇f)
        diff = self.ops.laplacian_diffusion(field, chi)
        
        # 2. Conversão de unidades para o termo fonte
        # Q [MW/m³] -> keV/s
        # 1 MW/m³ = 10^6 W/m^3
        # n_e em 10^20 m^-3 -> n_e_real = n_e * 10^20
        # e = 1.602e-16 J/keV
        # dT/dt = Q / (1.5 * n_e_real * e)
        # Q em MW/m³ = 10^6 W/m^3
        # n_e em 10^20 m^-3 -> n_e_real = n_e * 10^20
        # e = 1.602e-19 J/eV = 1.602e-16 J/keV
        # dT/dt = (source * 1e6) / (1.5 * density * 1e20 * 1.602e-16)
        # dT/dt = source / (density * 1.5 * 1e20 * 1.602e-16 * 1e-6)
        # dT/dt = source / (density * 1.5 * 16020 * 1e-6) -> Erro aqui!
        # Correção:
        # dT/dt = source / (density * 1.5 * 1.602e-2) = source / (density * 0.02403)
        source_conv = source / (density * 0.01602) # Q / (n_e * e_conv)
        
        # 3. Evolução temporal (Euler explícito)
        # ∂f/∂t = (1/capacity) * (diff/n_e + source_conv)
        capacity = 1.0 if is_density else 1.5
        
        # Nota: diff já é ∇·(χ ∇f)
        df_dt = (1.0 / capacity) * (diff / (density + 1e-10)) + source_conv / capacity
        
        if np.random.rand() < 0.001: # Print ocasional para diagnóstico
            print(f"DEBUG: source_conv mean = {source_conv.mean():.2e}, df_dt mean = {df_dt.mean():.2e}")
            
        new_field = field + df_dt * dt
        
        # 4. Condições de contorno
        # Borda (ρ=1)
        new_field[-1, :] = f_edge
        
        # Centro (ρ=0) - Simetria
        new_field[0, :] = new_field[1, :]
        
        # Garantir valores positivos
        new_field = np.maximum(new_field, 0.01)
        
        return new_field


if __name__ == "__main__":
    # Teste do solver explícito com aquecimento puro
    print("=" * 80)
    print("TESTE DO SOLVER EXPLÍCITO 2D")
    print("=" * 80)
    
    geom = TokamakGeometry2D()
    grid = Grid2D(n_rho=50, n_theta=32)
    ops = DifferentialOperators2D(geom, grid)
    solver = SolverExplicit2D(geom, grid, ops)
    
    T_e = np.ones((grid.n_rho, grid.n_theta)) * 0.1
    density = np.ones_like(T_e) * 5.0
    chi = np.zeros_like(T_e) # Sem transporte
    source = np.ones_like(T_e) * 100.0 # 100 MW/m³
    
    dt = 0.0001 # Passo pequeno para estabilidade explícita
    n_steps = 5000 # 0.5 s total
    for i in range(n_steps):
        T_e = solver.step(T_e, density, chi, source, dt)
        if (i+1) % 1000 == 0:
            print(f"Tempo {(i+1)*dt:.2f}s: T_e(centro) = {T_e[0,0]:.4f} keV")
        
    print(f"T_e final (centro): {T_e[0,0]:.4f} keV")
    # Esperado: 0.1 + 0.832 = 0.932 keV
    
    print("\n" + "=" * 80)
