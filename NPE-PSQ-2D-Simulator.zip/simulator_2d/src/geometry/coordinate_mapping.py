"""
Mapeamento de Coordenadas para o Simulador NPE-PSQ 2D

Este módulo implementa a conversão entre coordenadas cartesianas (R, Z)
e coordenadas toroidais (ρ, θ) usando métodos numéricos.
"""

import numpy as np
from typing import Tuple
import sys
sys.path.append('..')

from geometry.tokamak_geometry_2d import TokamakGeometry2D


class CoordinateMapper:
    """
    Realiza o mapeamento entre (R, Z) e (ρ, θ).
    """
    
    def __init__(self, geometry: TokamakGeometry2D):
        """
        Inicializa o mapeador.
        
        Args:
            geometry: Geometria do tokamak
        """
        self.geometry = geometry
    
    def cartesian_to_toroidal(self, R: float, Z: float, 
                             tol: float = 1e-6, 
                             max_iter: int = 20) -> Tuple[float, float]:
        """
        Converte (R, Z) para (ρ, θ) usando o método de Newton-Raphson.
        
        Args:
            R: Raio maior [m]
            Z: Altura [m]
            tol: Tolerância para convergência
            max_iter: Máximo de iterações
            
        Returns:
            Tupla (rho, theta)
        """
        # Estimativa inicial
        # rho ≈ sqrt((R-R0)^2 + (Z/kappa)^2) / a
        # theta ≈ atan2(Z/kappa, R-R0)
        dR = R - self.geometry.R0
        dZ = Z / self.geometry.kappa
        
        rho = np.sqrt(dR**2 + dZ**2) / self.geometry.a
        theta = np.arctan2(dZ, dR)
        
        # Newton-Raphson
        for _ in range(max_iter):
            # Calcular (R, Z) atuais
            R_curr = self.geometry.compute_R(rho, theta)
            Z_curr = self.geometry.compute_Z(rho, theta)
            
            # Erro
            f1 = R_curr - R
            f2 = Z_curr - Z
            
            if np.sqrt(f1**2 + f2**2) < tol:
                break
            
            # Jacobiano
            # J = |∂R/∂ρ  ∂R/∂θ|
            #     |∂Z/∂ρ  ∂Z/∂θ|
            
            # Derivadas (recalculadas aqui para precisão)
            theta_mod = theta + self.geometry.delta * np.sin(theta)
            dtheta_mod_dtheta = 1 + self.geometry.delta * np.cos(theta)
            
            dR_drho = self.geometry.a * np.cos(theta_mod)
            dR_dtheta = -rho * self.geometry.a * np.sin(theta_mod) * dtheta_mod_dtheta
            
            dZ_drho = self.geometry.a * self.geometry.kappa * np.sin(theta)
            dZ_dtheta = rho * self.geometry.a * self.geometry.kappa * np.cos(theta)
            
            det_J = dR_drho * dZ_dtheta - dR_dtheta * dZ_drho
            
            if abs(det_J) < 1e-10:
                break
            
            # Passo de Newton: Δx = -J^-1 * f
            drho = -(dZ_dtheta * f1 - dR_dtheta * f2) / det_J
            dtheta = -(-dZ_drho * f1 + dR_drho * f2) / det_J
            
            # Atualizar
            rho += drho
            theta += dtheta
            
        # Normalizar rho e theta
        rho = np.clip(rho, 0.0, 1.5) # Permitir um pouco fora da borda
        theta = theta % (2 * np.pi)
        
        return rho, theta

    def toroidal_to_cartesian(self, rho: float, theta: float) -> Tuple[float, float]:
        """
        Converte (ρ, θ) para (R, Z).
        
        Args:
            rho: Coordenada radial
            theta: Ângulo poloidal
            
        Returns:
            Tupla (R, Z)
        """
        R = self.geometry.compute_R(rho, theta)
        Z = self.geometry.compute_Z(rho, theta)
        return R, Z


if __name__ == "__main__":
    # Teste do módulo
    print("=" * 80)
    print("TESTE DO MÓDULO CoordinateMapper")
    print("=" * 80)
    
    geom = TokamakGeometry2D()
    mapper = CoordinateMapper(geom)
    
    # Testar pontos conhecidos
    test_points = [
        (0.5, 0.0),      # Meio do raio, lado externo
        (0.5, np.pi/2),  # Meio do raio, topo
        (0.8, np.pi),    # Perto da borda, lado interno
        (1.0, 3*np.pi/2) # Borda, fundo
    ]
    
    print(f"{'Original (ρ, θ)':<20} {'Cartesiano (R, Z)':<25} {'Recuperado (ρ, θ)':<20} {'Erro':<10}")
    print("-" * 80)
    
    for rho_orig, theta_orig in test_points:
        # Direto
        R, Z = mapper.toroidal_to_cartesian(rho_orig, theta_orig)
        
        # Reverso
        rho_rec, theta_rec = mapper.cartesian_to_toroidal(R, Z)
        
        # Erro
        err = np.sqrt((rho_orig - rho_rec)**2 + (theta_orig - theta_rec)**2)
        
        print(f"({rho_orig:.2f}, {theta_orig:.2f}) {'':<5} "
              f"({R:.2f}, {Z:.2f}) {'':<10} "
              f"({rho_rec:.2f}, {theta_rec:.2f}) {'':<5} "
              f"{err:.2e}")
    
    print("-" * 80)
    print("\n" + "=" * 80)
