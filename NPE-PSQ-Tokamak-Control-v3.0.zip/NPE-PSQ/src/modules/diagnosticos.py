"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Módulo de Diagnósticos e Visualização

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any
# Importações serão corrigidas no arquivo principal

# ==========================================
# FUNÇÕES DE DIAGNÓSTICO (A SEREM IMPORTADAS)
# ==========================================

def calculate_diagnostics(state, geometry, magnetic):
    """
    Calcula todos os parâmetros de diagnóstico para o estado atual.
    
    Args:
        state: PlasmaState
        geometry: TokamakGeometry
        magnetic: MagneticConfiguration
        
    Returns:
        Dicionário de diagnósticos
    """
    # Importações internas para evitar circular dependency
    from .fisica import DimensionlessParameters, FusionPower, PowerLosses
    
    q95 = DimensionlessParameters.safety_factor_q95(geometry, magnetic)
    beta_N = DimensionlessParameters.normalized_beta(state, geometry, magnetic)
    f_GW = DimensionlessParameters.greenwald_fraction(state, geometry, magnetic)
    P_fus = FusionPower.total_fusion_power(state, geometry)
    
    # Tempo de confinamento (simplificado via ITER89-P)
    # Requer potência de aquecimento, assumindo 50MW para cálculo estático
    P_heat_MW = 50.0 
    tau_E = PowerLosses.confinement_time_ITER89P(
        type('Config', (object,), {'geometry': geometry, 'magnetic': magnetic, 'state': state}),
        P_heat_MW
    )
    
    return {
        'q95': q95,
        'beta_N': beta_N,
        'f_GW': f_GW,
        'P_fus': P_fus,
        'tau_E': tau_E,
        'T_e': state.T_e,
        'Z': state.Z
    }

def print_summary(diagnostics: Dict[str, Any]):
    """Imprime um sumário formatado dos diagnósticos."""
    print("=" * 70)
    print("SUMÁRIO DE DIAGNÓSTICOS DO PLASMA")
    print("=" * 70)
    print(f"Fator de Segurança (q95):  {diagnostics['q95']:.2f}")
    print(f"Beta Normalizado (β_N):    {diagnostics['beta_N']:.2f} %")
    print(f"Tempo de Confinamento (τ_E): {diagnostics['tau_E']:.3f} s")
    print(f"Potência de Fusão (P_fus): {diagnostics['P_fus']:.2f} MW")
    print(f"Fração de Greenwald (f_GW): {diagnostics['f_GW']:.1%}")
    print(f"Temperatura Eletrônica (T_e): {diagnostics['T_e']:.2f} keV")
    print(f"Posição Vertical (Z):      {diagnostics['Z']:.4f} m")
    print("=" * 70)

def plot_history(history, config, filename="simulation_history.png"):
    """
    Plota resultados da simulação.
    
    Args:
        history: Histórico da simulação (dict)
        config: TokamakConfiguration
        filename: Nome do arquivo para salvar
    """
    time = history['time']
    states = history['state']
    
    # Extrai variáveis
    T_e = states[:, 0]
    Z = states[:, 4]
    
    # Calcula diagnósticos ao longo do tempo
    q95_history = []
    beta_N_history = []
    P_fus_history = []
    
    # Importações internas para evitar circular dependency
    from .fisica import PlasmaState, DimensionlessParameters, FusionPower
    
    for state_vec in states:
        state = PlasmaState.from_vector(state_vec)
        q95 = DimensionlessParameters.safety_factor_q95(config.geometry, config.magnetic)
        beta_N = DimensionlessParameters.normalized_beta(state, config.geometry, config.magnetic)
        P_fus = FusionPower.total_fusion_power(state, config.geometry)
        
        q95_history.append(q95)
        beta_N_history.append(beta_N)
        P_fus_history.append(P_fus)
    
    # Criar figura
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    fig.suptitle('NPE-PSQ Tokamak Simulator - Resultados', fontsize=16, fontweight='bold')
    
    # Temperatura
    axes[0, 0].plot(time, T_e, 'r-', linewidth=2, label='T_e')
    axes[0, 0].set_xlabel('Tempo [s]')
    axes[0, 0].set_ylabel('Temperatura [keV]')
    axes[0, 0].set_title('Evolução da Temperatura Eletrônica')
    axes[0, 0].grid(True, alpha=0.3)
    
    # Posição vertical
    axes[0, 1].plot(time, Z * 100, 'm-', linewidth=2)
    axes[0, 1].set_xlabel('Tempo [s]')
    axes[0, 1].set_ylabel('Posição Vertical [cm]')
    axes[0, 1].set_title('Controle de Posição Vertical')
    axes[0, 1].grid(True, alpha=0.3)
    
    # Fator de segurança
    axes[1, 0].plot(time, q95_history, 'c-', linewidth=2)
    axes[1, 0].set_xlabel('Tempo [s]')
    axes[1, 0].set_ylabel('q95')
    axes[1, 0].set_title('Fator de Segurança')
    axes[1, 0].grid(True, alpha=0.3)
    
    # Potência de fusão
    axes[1, 1].plot(time, P_fus_history, 'purple', linewidth=2)
    axes[1, 1].set_xlabel('Tempo [s]')
    axes[1, 1].set_ylabel('Potência [MW]')
    axes[1, 1].set_title('Potência de Fusão')
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f"/home/ubuntu/NPE-PSQ/assets/{filename}", dpi=150, bbox_inches='tight')
    print(f"  ✓ Gráficos salvos em: assets/{filename}")
    
    plt.close(fig)
