"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Integração Numérica: Runge-Kutta 4ª Ordem Adaptativo

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import numpy as np
from typing import Callable, Tuple
from src.tokamak_config import *
from src.plasma_dynamics import *

# ==========================================
# INTEGRADOR RK4 ADAPTATIVO
# ==========================================

class RK4Integrator:
    """
    Integrador Runge-Kutta de 4ª ordem com passo adaptativo
    """
    
    def __init__(self, 
                 dt_initial: float = 0.001,
                 dt_min: float = 1e-6,
                 dt_max: float = 0.01,
                 tolerance: float = 1e-4):
        """
        Inicializa o integrador
        
        Args:
            dt_initial: Passo de tempo inicial [s]
            dt_min: Passo de tempo mínimo [s]
            dt_max: Passo de tempo máximo [s]
            tolerance: Tolerância para controle adaptativo
        """
        self.dt = dt_initial
        self.dt_min = dt_min
        self.dt_max = dt_max
        self.tolerance = tolerance
        
        # Estatísticas
        self.steps_taken = 0
        self.steps_rejected = 0
    
    def step(self, 
             state_vec: np.ndarray,
             t: float,
             derivs_func: Callable,
             *args) -> Tuple[np.ndarray, float, bool]:
        """
        Executa um passo de integração RK4
        
        Args:
            state_vec: Vetor de estado atual
            t: Tempo atual [s]
            derivs_func: Função que calcula derivadas
            *args: Argumentos adicionais para derivs_func
        
        Returns:
            (novo_estado, novo_tempo, sucesso)
        """
        # Coeficientes RK4
        k1 = derivs_func(state_vec, t, *args)
        k2 = derivs_func(state_vec + 0.5 * self.dt * k1, t + 0.5 * self.dt, *args)
        k3 = derivs_func(state_vec + 0.5 * self.dt * k2, t + 0.5 * self.dt, *args)
        k4 = derivs_func(state_vec + self.dt * k3, t + self.dt, *args)
        
        # Novo estado (4ª ordem)
        state_new_4th = state_vec + (self.dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4)
        
        # Estimativa de 3ª ordem (para controle de erro)
        state_new_3rd = state_vec + (self.dt / 4.0) * (k1 + 3*k3)
        
        # Erro local
        error = np.max(np.abs(state_new_4th - state_new_3rd))
        
        # Controle adaptativo do passo
        if error < self.tolerance:
            # Aceita o passo
            self.steps_taken += 1
            
            # Aumenta dt se erro muito pequeno
            if error < 0.1 * self.tolerance:
                self.dt = min(self.dt * 1.5, self.dt_max)
            
            return state_new_4th, t + self.dt, True
        else:
            # Rejeita o passo e diminui dt
            self.steps_rejected += 1
            self.dt = max(self.dt * 0.5, self.dt_min)
            
            return state_vec, t, False
    
    def integrate(self,
                  state_initial: np.ndarray,
                  t_start: float,
                  t_end: float,
                  derivs_func: Callable,
                  *args) -> Tuple[np.ndarray, np.ndarray]:
        """
        Integra de t_start até t_end
        
        Args:
            state_initial: Estado inicial
            t_start: Tempo inicial [s]
            t_end: Tempo final [s]
            derivs_func: Função de derivadas
            *args: Argumentos adicionais
        
        Returns:
            (array_de_tempos, array_de_estados)
        """
        # Inicialização
        t = t_start
        state = state_initial.copy()
        
        # Listas para armazenar histórico
        times = [t]
        states = [state.copy()]
        
        # Loop de integração
        while t < t_end:
            # Ajusta último passo para não ultrapassar t_end
            if t + self.dt > t_end:
                self.dt = t_end - t
            
            # Executa passo
            state_new, t_new, success = self.step(state, t, derivs_func, *args)
            
            if success:
                state = state_new
                t = t_new
                
                times.append(t)
                states.append(state.copy())
        
        return np.array(times), np.array(states)
    
    def get_statistics(self):
        """Retorna estatísticas de integração"""
        total_steps = self.steps_taken + self.steps_rejected
        acceptance_rate = self.steps_taken / total_steps if total_steps > 0 else 0
        
        return {
            'steps_taken': self.steps_taken,
            'steps_rejected': self.steps_rejected,
            'acceptance_rate': acceptance_rate,
            'final_dt': self.dt
        }

# ==========================================
# FUNÇÃO DE DERIVADAS PARA O TOKAMAK
# ==========================================

class TokamakDerivatives:
    """
    Calcula derivadas temporais do estado do plasma
    """
    
    def __init__(self, 
                 geometry: TokamakGeometry,
                 magnetic: MagneticConfiguration):
        self.geometry = geometry
        self.magnetic = magnetic
    
    def compute(self, 
                state_vec: np.ndarray,
                t: float,
                actuators: ControlActuators) -> np.ndarray:
        """
        Calcula dX/dt para o vetor de estado
        
        Vetor de estado:
        X = [T_e, T_i, n_e, n_i, Z, Z_dot, l_i, P_rad]
        
        Args:
            state_vec: Vetor de estado
            t: Tempo [s]
            actuators: Atuadores de controle
        
        Returns:
            dX/dt
        """
        # Converte vetor para PlasmaState
        state = PlasmaState.from_vector(state_vec)
        
        # Calcula derivadas
        dT_e = PlasmaEvolution.dTe_dt(
            state, self.geometry, self.magnetic,
            actuators.P_ECRH + 0.5 * actuators.P_NBI  # Aquecimento eletrônico
        )
        
        dT_i = PlasmaEvolution.dTi_dt(
            state, self.geometry,
            actuators.P_ICRH + 0.5 * actuators.P_NBI  # Aquecimento iônico
        )
        
        # Densidade (simplificado: constante ou com fonte)
        dn_e = 0.0
        dn_i = 0.0
        
        # Posição vertical
        dZ = PlasmaEvolution.dZ_dt(state)
        
        dZ_dot = PlasmaEvolution.dZ_dot_dt(
            state, self.geometry, self.magnetic, actuators.F_z
        )
        
        # Índice de inductância (simplificado: evolução lenta)
        dl_i = 0.0
        
        # Potência radiativa (simplificado)
        dP_rad = 0.0
        
        # Monta vetor de derivadas
        derivs = np.array([
            dT_e, dT_i,
            dn_e, dn_i,
            dZ, dZ_dot,
            dl_i, dP_rad
        ])
        
        return derivs

# ==========================================
# SIMULADOR DE TOKAMAK
# ==========================================

class TokamakSimulator:
    """
    Simulador completo de tokamak com integração RK4
    """
    
    def __init__(self, config: TokamakConfiguration):
        self.config = config
        self.integrator = RK4Integrator()
        self.derivatives = TokamakDerivatives(
            config.geometry,
            config.magnetic
        )
        
        # Histórico
        self.history = {
            'time': [],
            'state': [],
            'actuators': [],
            'diagnostics': []
        }
    
    def simulate(self,
                 t_end: float,
                 actuators: ControlActuators,
                 controller: Optional[Callable] = None):
        """
        Executa simulação de 0 até t_end
        
        Args:
            t_end: Tempo final [s]
            actuators: Atuadores de controle (fixos ou função do tempo)
            controller: Função de controle opcional (state, t) -> actuators
        
        Returns:
            Histórico de simulação
        """
        # Estado inicial
        state_vec = self.config.state.to_vector()
        t = 0.0
        
        # Limpa histórico
        self.history = {
            'time': [t],
            'state': [state_vec.copy()],
            'actuators': [actuators.to_vector()],
            'diagnostics': []
        }
        
        # Loop de simulação
        while t < t_end:
            # Atualiza controle se houver controlador
            if controller is not None:
                state = PlasmaState.from_vector(state_vec)
                actuators = controller(state, t)
            
            # Função de derivadas com atuadores fixos
            def derivs_with_actuators(state_vec, t):
                return self.derivatives.compute(state_vec, t, actuators)
            
            # Executa passo de integração
            state_new, t_new, success = self.integrator.step(
                state_vec, t, derivs_with_actuators
            )
            
            if success:
                state_vec = state_new
                t = t_new
                
                # Armazena histórico
                self.history['time'].append(t)
                self.history['state'].append(state_vec.copy())
                self.history['actuators'].append(actuators.to_vector())
        
        # Converte para arrays numpy
        self.history['time'] = np.array(self.history['time'])
        self.history['state'] = np.array(self.history['state'])
        self.history['actuators'] = np.array(self.history['actuators'])
        
        return self.history
    
    def get_final_state(self) -> PlasmaState:
        """Retorna estado final da simulação"""
        final_vec = self.history['state'][-1]
        return PlasmaState.from_vector(final_vec)
    
    def print_statistics(self):
        """Imprime estatísticas de integração"""
        stats = self.integrator.get_statistics()
        
        print("=" * 70)
        print("ESTATÍSTICAS DE INTEGRAÇÃO")
        print("=" * 70)
        print(f"Passos Aceitos:        {stats['steps_taken']}")
        print(f"Passos Rejeitados:     {stats['steps_rejected']}")
        print(f"Taxa de Aceitação:     {stats['acceptance_rate']:.1%}")
        print(f"Passo Final (dt):      {stats['final_dt']:.2e} s")
        print("=" * 70)

# ==========================================
# TESTE
# ==========================================

if __name__ == "__main__":
    print("=" * 70)
    print("TESTE DE INTEGRAÇÃO NUMÉRICA RK4")
    print("=" * 70)
    
    # Criar configuração
    config = create_iter_like_config()
    
    # Criar simulador
    simulator = TokamakSimulator(config)
    
    # Definir atuadores
    actuators = ControlActuators(
        P_NBI=20.0,
        P_ECRH=10.0,
        P_ICRH=15.0,
        F_z=0.0
    )
    
    # Executar simulação
    print("\nExecutando simulação de 10 segundos...")
    history = simulator.simulate(t_end=10.0, actuators=actuators)
    
    # Estado final
    final_state = simulator.get_final_state()
    print(f"\nEstado Final:")
    print(f"  T_e = {final_state.T_e:.2f} keV")
    print(f"  T_i = {final_state.T_i:.2f} keV")
    print(f"  Z = {final_state.Z:.3f} m")
    
    # Estatísticas
    simulator.print_statistics()
    
    print(f"\nPontos de tempo simulados: {len(history['time'])}")
    print(f"Tempo total: {history['time'][-1]:.2f} s")
