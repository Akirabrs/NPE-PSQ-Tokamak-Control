"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Plasma Stability Quenching (PSQ): Sistema de Segurança Determinístico

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import numpy as np
from enum import Enum
from dataclasses import dataclass
from typing import Tuple, Optional
from src.tokamak_config import *
from src.plasma_dynamics import *

# ==========================================
# CÓDIGOS DE AÇÃO DE SEGURANÇA
# ==========================================

class SafetyActionCode(Enum):
    """
    Códigos de ação de segurança
    """
    NORMAL = 0
    KILLER_PULSE = 1          # Disrupção magnética iminente
    MASSIVE_GAS_INJECTION = 2  # Densidade excessiva
    VERTICAL_STABILIZATION = 3  # VDE iminente
    EMERGENCY_SHUTDOWN = 4     # Shutdown total
    POWER_REDUCTION = 5        # Redução de potência

# ==========================================
# LIMITES DE SEGURANÇA
# ==========================================

@dataclass
class SafetyLimits:
    """
    Limites operacionais de segurança
    """
    # Fator de segurança
    q95_min: float = 2.0
    q95_max: float = 6.0
    
    # Beta normalizado
    beta_N_max: float = 3.5
    
    # Densidade (fração de Greenwald)
    density_fraction_max: float = 0.95
    
    # Posição vertical
    Z_max: float = 0.1  # [m]
    Z_dot_max: float = 1.0  # [m/s]
    
    # Temperatura
    T_e_max: float = 30.0  # [keV]
    T_e_min: float = 1.0   # [keV]
    
    # Potência radiativa (fração da potência total)
    P_rad_fraction_max: float = 0.7

# ==========================================
# SISTEMA DE SEGURANÇA PSQ
# ==========================================

class PlasmaStabilityQuenching:
    """
    Sistema de segurança determinístico de ultra-baixa latência
    
    Características:
    - Lógica puramente determinística (sem IA)
    - Latência de nanosegundos (implementável em FPGA)
    - Prioridade máxima sobre qualquer controlador
    """
    
    def __init__(self, limits: Optional[SafetyLimits] = None):
        self.limits = limits if limits is not None else SafetyLimits()
        
        # Histórico de eventos de segurança
        self.safety_events = []
        
        # Contadores
        self.total_checks = 0
        self.violations_detected = 0
    
    def check_safety(self,
                    state: PlasmaState,
                    geometry: TokamakGeometry,
                    magnetic: MagneticConfiguration) -> Tuple[bool, SafetyActionCode, str]:
        """
        Verificação de segurança de latência zero
        
        Args:
            state: Estado atual do plasma
            geometry: Geometria do tokamak
            magnetic: Configuração magnética
        
        Returns:
            (is_safe, action_code, message)
        """
        self.total_checks += 1
        
        # 1. Verifica fator de segurança (q95)
        q95 = DimensionlessParameters.safety_factor_q95(geometry, magnetic)
        
        if q95 < self.limits.q95_min:
            self.violations_detected += 1
            self._log_event(SafetyActionCode.KILLER_PULSE, f"q95={q95:.2f} < {self.limits.q95_min}")
            return False, SafetyActionCode.KILLER_PULSE, \
                   f"TEARING MODE RISK: q95={q95:.2f} abaixo do limite"
        
        # 2. Verifica beta normalizado
        beta_N = DimensionlessParameters.normalized_beta(state, geometry, magnetic)
        
        if beta_N > self.limits.beta_N_max:
            self.violations_detected += 1
            self._log_event(SafetyActionCode.POWER_REDUCTION, f"β_N={beta_N:.2f} > {self.limits.beta_N_max}")
            return False, SafetyActionCode.POWER_REDUCTION, \
                   f"PRESSURE LIMIT: β_N={beta_N:.2f} acima do limite"
        
        # 3. Verifica densidade (Greenwald)
        f_GW = DimensionlessParameters.greenwald_fraction(state, geometry, magnetic)
        
        if f_GW > self.limits.density_fraction_max:
            self.violations_detected += 1
            self._log_event(SafetyActionCode.MASSIVE_GAS_INJECTION, f"f_GW={f_GW:.2%}")
            return False, SafetyActionCode.MASSIVE_GAS_INJECTION, \
                   f"DENSITY LIMIT: {f_GW:.1%} do limite de Greenwald"
        
        # 4. Verifica posição vertical (VDE)
        if abs(state.Z) > self.limits.Z_max:
            self.violations_detected += 1
            self._log_event(SafetyActionCode.VERTICAL_STABILIZATION, f"Z={state.Z:.3f}m")
            return False, SafetyActionCode.VERTICAL_STABILIZATION, \
                   f"VDE RISK: Deslocamento vertical Z={state.Z:.3f}m"
        
        # 5. Verifica velocidade vertical
        if abs(state.Z_dot) > self.limits.Z_dot_max:
            self.violations_detected += 1
            self._log_event(SafetyActionCode.VERTICAL_STABILIZATION, f"Z_dot={state.Z_dot:.2f}m/s")
            return False, SafetyActionCode.VERTICAL_STABILIZATION, \
                   f"VDE RISK: Velocidade vertical Z_dot={state.Z_dot:.2f}m/s"
        
        # 6. Verifica temperatura
        if state.T_e > self.limits.T_e_max or state.T_e < self.limits.T_e_min:
            self.violations_detected += 1
            self._log_event(SafetyActionCode.EMERGENCY_SHUTDOWN, f"T_e={state.T_e:.1f}keV")
            return False, SafetyActionCode.EMERGENCY_SHUTDOWN, \
                   f"TEMPERATURE ANOMALY: T_e={state.T_e:.1f}keV fora dos limites"
        
        # 7. Verifica potência radiativa
        P_rad_fraction = state.P_rad / 100.0  # Simplificado
        
        if P_rad_fraction > self.limits.P_rad_fraction_max:
            self.violations_detected += 1
            self._log_event(SafetyActionCode.POWER_REDUCTION, f"P_rad={P_rad_fraction:.1%}")
            return False, SafetyActionCode.POWER_REDUCTION, \
                   f"RADIATION LIMIT: P_rad={P_rad_fraction:.1%} da potência total"
        
        # Tudo OK
        return True, SafetyActionCode.NORMAL, "Sistema operando normalmente"
    
    def _log_event(self, action_code: SafetyActionCode, details: str):
        """
        Registra evento de segurança
        
        Args:
            action_code: Código da ação
            details: Detalhes do evento
        """
        self.safety_events.append({
            'action': action_code,
            'details': details,
            'check_number': self.total_checks
        })
    
    def get_mitigation_action(self, 
                             action_code: SafetyActionCode,
                             current_actuators: ControlActuators) -> ControlActuators:
        """
        Retorna ação de mitigação apropriada
        
        Args:
            action_code: Código de ação de segurança
            current_actuators: Atuadores atuais
        
        Returns:
            Atuadores de mitigação
        """
        if action_code == SafetyActionCode.KILLER_PULSE:
            # Reduz corrente de plasma rapidamente
            return ControlActuators(
                P_NBI=0.0,
                P_ECRH=0.0,
                P_ICRH=0.0,
                F_z=0.0,
                V_coil_upper=-10.0,  # Pulso negativo
                V_coil_lower=-10.0
            )
        
        elif action_code == SafetyActionCode.MASSIVE_GAS_INJECTION:
            # Injeta gás para resfriar plasma
            return ControlActuators(
                P_NBI=current_actuators.P_NBI * 0.5,
                P_ECRH=current_actuators.P_ECRH * 0.5,
                P_ICRH=current_actuators.P_ICRH * 0.5,
                F_z=current_actuators.F_z
            )
        
        elif action_code == SafetyActionCode.VERTICAL_STABILIZATION:
            # Estabilização vertical agressiva
            return ControlActuators(
                P_NBI=current_actuators.P_NBI,
                P_ECRH=current_actuators.P_ECRH,
                P_ICRH=current_actuators.P_ICRH,
                F_z=-5.0 if current_actuators.F_z > 0 else 5.0  # Força oposta
            )
        
        elif action_code == SafetyActionCode.POWER_REDUCTION:
            # Reduz potência de aquecimento
            return ControlActuators(
                P_NBI=current_actuators.P_NBI * 0.7,
                P_ECRH=current_actuators.P_ECRH * 0.7,
                P_ICRH=current_actuators.P_ICRH * 0.7,
                F_z=current_actuators.F_z
            )
        
        elif action_code == SafetyActionCode.EMERGENCY_SHUTDOWN:
            # Shutdown total
            return ControlActuators(
                P_NBI=0.0,
                P_ECRH=0.0,
                P_ICRH=0.0,
                F_z=0.0,
                V_coil_upper=0.0,
                V_coil_lower=0.0
            )
        
        else:
            # Normal: sem modificação
            return current_actuators
    
    def print_statistics(self):
        """Imprime estatísticas do sistema de segurança"""
        print("=" * 70)
        print("ESTATÍSTICAS DO SISTEMA DE SEGURANÇA PSQ")
        print("=" * 70)
        print(f"Total de Verificações:     {self.total_checks}")
        print(f"Violações Detectadas:      {self.violations_detected}")
        
        if self.total_checks > 0:
            violation_rate = self.violations_detected / self.total_checks * 100
            print(f"Taxa de Violação:          {violation_rate:.2f}%")
        
        if self.safety_events:
            print(f"\nÚltimos Eventos de Segurança:")
            for event in self.safety_events[-5:]:  # Últimos 5
                print(f"  [{event['check_number']}] {event['action'].name}: {event['details']}")
        
        print("=" * 70)

# ==========================================
# SISTEMA INTEGRADO NPE-PSQ
# ==========================================

class IntegratedNPEPSQ:
    """
    Sistema integrado: NPE (Neural) + PSQ (Safety)
    
    Fluxo de controle:
    1. PSQ verifica segurança (prioridade máxima)
    2. Se seguro, NPE calcula controle
    3. PSQ valida controle antes de aplicar
    """
    
    def __init__(self,
                 neural_controller,
                 safety_system: PlasmaStabilityQuenching,
                 geometry: TokamakGeometry,
                 magnetic: MagneticConfiguration):
        self.neural_controller = neural_controller
        self.safety_system = safety_system
        self.geometry = geometry
        self.magnetic = magnetic
        
        # Estatísticas
        self.safety_overrides = 0
        self.normal_operations = 0
    
    def compute_safe_control(self, state: PlasmaState) -> Tuple[ControlActuators, bool, str]:
        """
        Calcula controle com verificação de segurança
        
        Args:
            state: Estado atual do plasma
        
        Returns:
            (actuators, is_safe, message)
        """
        # 1. Verificação de segurança do estado
        is_safe, action_code, message = self.safety_system.check_safety(
            state, self.geometry, self.magnetic
        )
        
        if not is_safe:
            # Sistema de segurança assume controle
            self.safety_overrides += 1
            
            # Calcula controle de mitigação
            mitigation_actuators = self.safety_system.get_mitigation_action(
                action_code,
                ControlActuators()  # Atuadores zerados
            )
            
            return mitigation_actuators, False, f"[PSQ] {message}"
        
        # 2. Estado seguro: NPE calcula controle
        neural_actuators = self.neural_controller.compute_control(state)
        
        # 3. Valida controle (verificação adicional)
        # Aqui poderia haver validação dos limites de atuadores
        
        self.normal_operations += 1
        return neural_actuators, True, "[NPE] Controle neural ativo"
    
    def print_statistics(self):
        """Imprime estatísticas do sistema integrado"""
        total_ops = self.safety_overrides + self.normal_operations
        
        print("=" * 70)
        print("ESTATÍSTICAS DO SISTEMA INTEGRADO NPE-PSQ")
        print("=" * 70)
        print(f"Operações Normais (NPE):   {self.normal_operations}")
        print(f"Intervenções de Segurança: {self.safety_overrides}")
        
        if total_ops > 0:
            safety_rate = self.safety_overrides / total_ops * 100
            print(f"Taxa de Intervenção:       {safety_rate:.2f}%")
        
        print("=" * 70)

# ==========================================
# TESTE
# ==========================================

if __name__ == "__main__":
    print("=" * 70)
    print("TESTE DO SISTEMA DE SEGURANÇA PSQ")
    print("=" * 70)
    
    # Criar configuração
    config = create_iter_like_config()
    
    # Criar sistema de segurança
    psq = PlasmaStabilityQuenching()
    
    # Teste 1: Estado seguro
    print("\nTeste 1: Estado Normal")
    safe_state = PlasmaState(
        T_e=10.0, T_i=10.0,
        n_e=1.0e20, n_i=1.0e20,
        Z=0.0, Z_dot=0.0
    )
    
    is_safe, code, msg = psq.check_safety(safe_state, config.geometry, config.magnetic)
    print(f"  Resultado: {'✓ SEGURO' if is_safe else '✗ VIOLAÇÃO'}")
    print(f"  Código: {code.name}")
    print(f"  Mensagem: {msg}")
    
    # Teste 2: q95 baixo (risco de tearing mode)
    print("\nTeste 2: q95 Baixo (Risco de Tearing Mode)")
    # Aumenta corrente para reduzir q95
    config_low_q = create_iter_like_config()
    config_low_q.magnetic.I_p = 20.0  # Aumenta corrente
    
    is_safe, code, msg = psq.check_safety(safe_state, config_low_q.geometry, config_low_q.magnetic)
    print(f"  Resultado: {'✓ SEGURO' if is_safe else '✗ VIOLAÇÃO'}")
    print(f"  Código: {code.name}")
    print(f"  Mensagem: {msg}")
    
    # Teste 3: Deslocamento vertical
    print("\nTeste 3: Deslocamento Vertical (VDE)")
    vde_state = PlasmaState(
        T_e=10.0, T_i=10.0,
        n_e=1.0e20, n_i=1.0e20,
        Z=0.15,  # Acima do limite
        Z_dot=0.5
    )
    
    is_safe, code, msg = psq.check_safety(vde_state, config.geometry, config.magnetic)
    print(f"  Resultado: {'✓ SEGURO' if is_safe else '✗ VIOLAÇÃO'}")
    print(f"  Código: {code.name}")
    print(f"  Mensagem: {msg}")
    
    # Estatísticas
    psq.print_statistics()
