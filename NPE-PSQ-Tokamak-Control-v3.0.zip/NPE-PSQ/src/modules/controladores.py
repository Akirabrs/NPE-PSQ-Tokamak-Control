"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Controlador Model Predictive Control (MPC)

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import numpy as np
import cvxpy as cp
from dataclasses import dataclass
from typing import Dict, Optional
from src.tokamak_config import *
from src.plasma_dynamics import *

# ==========================================
# CONFIGURAÇÃO DO MPC
# ==========================================

@dataclass
class MPCConfig:
    """
    Parâmetros de configuração do MPC
    """
    # Horizonte de predição
    N: int = 20
    
    # Setpoints de referência
    T_e_ref: float = 10.0  # [keV]
    T_i_ref: float = 10.0  # [keV]
    Z_ref: float = 0.0     # [m]
    
    # Pesos da função custo (Q matrix)
    w_T_e: float = 100.0
    w_T_i: float = 100.0
    w_Z: float = 1000.0
    w_Z_dot: float = 100.0
    
    # Pesos de controle (R matrix)
    w_P_NBI: float = 0.1
    w_P_ECRH: float = 0.1
    w_P_ICRH: float = 0.1
    w_F_z: float = 1.0
    
    # Limites de atuadores
    P_NBI_max: float = 33.0   # [MW]
    P_ECRH_max: float = 20.0  # [MW]
    P_ICRH_max: float = 20.0  # [MW]
    F_z_max: float = 5.0      # [MN]
    
    # Passo de tempo
    dt: float = 0.1  # [s]

# ==========================================
# CONTROLADOR MPC
# ==========================================

class MPCController:
    """
    Controlador Model Predictive Control para tokamak
    
    Minimiza:
        J = Σ ||x_k - x_ref||²_Q + ||u_k||²_R
    
    Sujeito a:
        x_{k+1} = A x_k + B u_k  (dinâmica linearizada)
        u_min ≤ u_k ≤ u_max
    """
    
    def __init__(self,
                 geometry: TokamakGeometry,
                 magnetic: MagneticConfiguration,
                 config: MPCConfig):
        self.geometry = geometry
        self.magnetic = magnetic
        self.config = config
        
        # Matrizes de linearização (calculadas em tempo de execução)
        self.A = None
        self.B = None
        
        # Problema de otimização (construído uma vez)
        self._build_optimization_problem()
    
    def _build_optimization_problem(self):
        """
        Constrói o problema de otimização CVXPY
        """
        N = self.config.N
        
        # Dimensões
        n_states = 4  # [T_e, T_i, Z, Z_dot]
        n_controls = 4  # [P_NBI, P_ECRH, P_ICRH, F_z]
        
        # Variáveis de decisão
        self.x_var = cp.Variable((n_states, N+1))  # Estados
        self.u_var = cp.Variable((n_controls, N))  # Controles
        
        # Parâmetros
        self.x0_param = cp.Parameter(n_states)  # Estado inicial
        self.x_ref_param = cp.Parameter(n_states)  # Referência
        self.A_param = cp.Parameter((n_states, n_states))  # Matriz A
        self.B_param = cp.Parameter((n_states, n_controls))  # Matriz B
        
        # Matrizes de peso
        Q = np.diag([
            self.config.w_T_e,
            self.config.w_T_i,
            self.config.w_Z,
            self.config.w_Z_dot
        ])
        
        R = np.diag([
            self.config.w_P_NBI,
            self.config.w_P_ECRH,
            self.config.w_P_ICRH,
            self.config.w_F_z
        ])
        
        # Função custo
        cost = 0
        constraints = []
        
        # Condição inicial
        constraints.append(self.x_var[:, 0] == self.x0_param)
        
        # Loop sobre horizonte
        for k in range(N):
            # Custo de tracking
            error = self.x_var[:, k] - self.x_ref_param
            cost += cp.quad_form(error, Q)
            
            # Custo de controle
            cost += cp.quad_form(self.u_var[:, k], R)
            
            # Dinâmica
            constraints.append(
                self.x_var[:, k+1] == self.A_param @ self.x_var[:, k] + 
                                      self.B_param @ self.u_var[:, k]
            )
            
            # Limites de controle
            constraints.append(self.u_var[0, k] >= 0)  # P_NBI
            constraints.append(self.u_var[0, k] <= self.config.P_NBI_max)
            
            constraints.append(self.u_var[1, k] >= 0)  # P_ECRH
            constraints.append(self.u_var[1, k] <= self.config.P_ECRH_max)
            
            constraints.append(self.u_var[2, k] >= 0)  # P_ICRH
            constraints.append(self.u_var[2, k] <= self.config.P_ICRH_max)
            
            constraints.append(self.u_var[3, k] >= -self.config.F_z_max)  # F_z
            constraints.append(self.u_var[3, k] <= self.config.F_z_max)
        
        # Custo terminal
        error_final = self.x_var[:, N] - self.x_ref_param
        cost += cp.quad_form(error_final, Q)
        
        # Problema de otimização
        self.problem = cp.Problem(cp.Minimize(cost), constraints)
    
    def _linearize_dynamics(self, state: PlasmaState) -> tuple:
        """
        Lineariza a dinâmica em torno do estado atual
        
        x_{k+1} ≈ A x_k + B u_k
        
        Args:
            state: Estado atual do plasma
        
        Returns:
            (A, B) matrizes de linearização
        """
        dt = self.config.dt
        
        # Matriz A (identidade + derivadas parciais)
        # Simplificação: assume dinâmica desacoplada
        A = np.eye(4)
        
        # Temperatura eletrônica decai naturalmente
        tau_E = 0.1  # Tempo de confinamento típico [s]
        A[0, 0] = 1.0 - dt / tau_E
        
        # Temperatura iônica acopla com eletrônica
        A[1, 1] = 1.0 - dt / tau_E
        A[1, 0] = dt / tau_E * 0.5  # Acoplamento
        
        # Posição vertical
        A[2, 3] = dt  # Z += Z_dot * dt
        
        # Velocidade vertical (restauração)
        k_z = 1e7  # [N/m]
        M_eff = state.n_i * DEUTERIUM_MASS * self.geometry.volume
        A[3, 2] = -dt * k_z / M_eff
        A[3, 3] = 1.0 - dt * 0.1  # Amortecimento
        
        # Matriz B (efeito dos controles)
        B = np.zeros((4, 4))
        
        # Aquecimento afeta temperaturas
        C_thermal_e = (3.0/2.0) * state.n_e * BOLTZMANN_CONSTANT * self.geometry.volume / 1e3
        C_thermal_i = (3.0/2.0) * state.n_i * BOLTZMANN_CONSTANT * self.geometry.volume / 1e3
        
        # P_NBI aquece ambos (50/50)
        B[0, 0] = dt * 0.5 * MW_to_W(1.0) / C_thermal_e
        B[1, 0] = dt * 0.5 * MW_to_W(1.0) / C_thermal_i
        
        # P_ECRH aquece elétrons
        B[0, 1] = dt * MW_to_W(1.0) / C_thermal_e
        
        # P_ICRH aquece íons
        B[1, 2] = dt * MW_to_W(1.0) / C_thermal_i
        
        # F_z afeta velocidade vertical
        B[3, 3] = dt * 1e6 / M_eff  # MN para N
        
        return A, B
    
    def compute_control(self, state: PlasmaState) -> ControlActuators:
        """
        Calcula controle ótimo via MPC
        
        Args:
            state: Estado atual do plasma
        
        Returns:
            Atuadores de controle otimizados
        """
        # Lineariza dinâmica
        A, B = self._linearize_dynamics(state)
        
        # Estado atual (reduzido)
        x0 = np.array([state.T_e, state.T_i, state.Z, state.Z_dot])
        
        # Referência
        x_ref = np.array([
            self.config.T_e_ref,
            self.config.T_i_ref,
            self.config.Z_ref,
            0.0  # Z_dot_ref = 0
        ])
        
        # Atualiza parâmetros
        self.x0_param.value = x0
        self.x_ref_param.value = x_ref
        self.A_param.value = A
        self.B_param.value = B
        
        # Resolve problema
        try:
            self.problem.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            
            if self.problem.status == cp.OPTIMAL:
                # Extrai primeiro controle (receding horizon)
                u_opt = self.u_var[:, 0].value
                
                return ControlActuators(
                    P_NBI=float(u_opt[0]),
                    P_ECRH=float(u_opt[1]),
                    P_ICRH=float(u_opt[2]),
                    F_z=float(u_opt[3])
                )
            else:
                print(f"[MPC] Otimização falhou: {self.problem.status}")
                return self._fallback_control(state)
        
        except Exception as e:
            print(f"[MPC] Erro: {e}")
            return self._fallback_control(state)
    
    def _fallback_control(self, state: PlasmaState) -> ControlActuators:
        """
        Controle de fallback (PID simples)
        
        Args:
            state: Estado atual
        
        Returns:
            Controle de segurança
        """
        # PID simples para temperatura
        K_p = 2.0
        error_T = self.config.T_e_ref - state.T_e
        P_heat = K_p * error_T
        P_heat = np.clip(P_heat, 0, 50.0)
        
        # PID para posição vertical
        K_p_z = 100.0
        K_d_z = 10.0
        error_Z = self.config.Z_ref - state.Z
        F_z = K_p_z * error_Z - K_d_z * state.Z_dot
        F_z = np.clip(F_z, -self.config.F_z_max, self.config.F_z_max)
        
        return ControlActuators(
            P_NBI=P_heat * 0.5,
            P_ECRH=P_heat * 0.3,
            P_ICRH=P_heat * 0.2,
            F_z=F_z
        )

# ==========================================
# TESTE
# ==========================================

if __name__ == "__main__":
    print("=" * 70)
    print("TESTE DO CONTROLADOR MPC")
    print("=" * 70)
    
    # Criar configuração
    config = create_iter_like_config()
    
    # Configuração do MPC
    mpc_config = MPCConfig(
        N=15,
        T_e_ref=12.0,
        T_i_ref=12.0,
        Z_ref=0.0
    )
    
    # Criar controlador
    controller = MPCController(
        config.geometry,
        config.magnetic,
        mpc_config
    )
    
    # Estado de teste (abaixo da referência)
    test_state = PlasmaState(
        T_e=8.0,
        T_i=8.0,
        n_e=1.0e20,
        n_i=1.0e20,
        Z=0.05,
        Z_dot=0.1
    )
    
    print("\nEstado Atual:")
    print(f"  T_e = {test_state.T_e:.2f} keV (ref: {mpc_config.T_e_ref:.2f})")
    print(f"  T_i = {test_state.T_i:.2f} keV (ref: {mpc_config.T_i_ref:.2f})")
    print(f"  Z = {test_state.Z:.3f} m (ref: {mpc_config.Z_ref:.3f})")
    
    # Calcula controle
    print("\nCalculando controle MPC...")
    actuators = controller.compute_control(test_state)
    
    print("\nControle Otimizado:")
    print(f"  P_NBI = {actuators.P_NBI:.2f} MW")
    print(f"  P_ECRH = {actuators.P_ECRH:.2f} MW")
    print(f"  P_ICRH = {actuators.P_ICRH:.2f} MW")
    print(f"  F_z = {actuators.F_z:.2f} MN")
    print(f"  P_total = {actuators.total_heating_power():.2f} MW")
    
    print("=" * 70)
"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Neural Predictive Engine (NPE): Rede Neural para Controle Rápido

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import Optional, List, Tuple
from src.tokamak_config import *
from src.mpc_controller import *

# ==========================================
# ARQUITETURA DA REDE NEURAL
# ==========================================

class NeuralPredictiveEngine(nn.Module):
    """
    Rede Neural que clona o comportamento do MPC
    
    Arquitetura: MLP otimizado para FPGA
    Input: Estado do plasma (10 dimensões)
    Output: Ações de controle (4 dimensões)
    """
    
    def __init__(self, 
                 input_dim: int = 10,
                 hidden_dims: List[int] = [64, 64, 32],
                 output_dim: int = 4):
        super(NeuralPredictiveEngine, self).__init__()
        
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Camadas
        layers = []
        
        # Primeira camada
        layers.append(nn.Linear(input_dim, hidden_dims[0]))
        layers.append(nn.BatchNorm1d(hidden_dims[0]))
        layers.append(nn.ReLU())
        
        # Camadas intermediárias
        for i in range(len(hidden_dims) - 1):
            layers.append(nn.Linear(hidden_dims[i], hidden_dims[i+1]))
            layers.append(nn.BatchNorm1d(hidden_dims[i+1]))
            layers.append(nn.ReLU())
        
        # Camada de saída
        layers.append(nn.Linear(hidden_dims[-1], output_dim))
        
        self.network = nn.Sequential(*layers)
        
        # Normalização de entrada/saída (aprendida durante treino)
        self.register_buffer('input_mean', torch.zeros(input_dim))
        self.register_buffer('input_std', torch.ones(input_dim))
        self.register_buffer('output_mean', torch.zeros(output_dim))
        self.register_buffer('output_std', torch.ones(output_dim))
    
    def forward(self, x):
        """
        Forward pass
        
        Args:
            x: Tensor de entrada [batch, input_dim]
        
        Returns:
            Tensor de saída [batch, output_dim]
        """
        # Normaliza entrada
        x_norm = (x - self.input_mean) / (self.input_std + 1e-8)
        
        # Passa pela rede
        y_norm = self.network(x_norm)
        
        # Desnormaliza saída
        y = y_norm * self.output_std + self.output_mean
        
        return y
    
    def set_normalization(self, 
                         input_mean: np.ndarray,
                         input_std: np.ndarray,
                         output_mean: np.ndarray,
                         output_std: np.ndarray):
        """
        Define parâmetros de normalização
        
        Args:
            input_mean: Média das entradas
            input_std: Desvio padrão das entradas
            output_mean: Média das saídas
            output_std: Desvio padrão das saídas
        """
        self.input_mean = torch.tensor(input_mean, dtype=torch.float32)
        self.input_std = torch.tensor(input_std, dtype=torch.float32)
        self.output_mean = torch.tensor(output_mean, dtype=torch.float32)
        self.output_std = torch.tensor(output_std, dtype=torch.float32)
    
    def export_to_onnx(self, filename: str = "npe_model.onnx"):
        """
        Exporta modelo para formato ONNX (compatível com FPGA)
        
        Args:
            filename: Nome do arquivo de saída
        """
        dummy_input = torch.randn(1, self.input_dim)
        torch.onnx.export(
            self,
            dummy_input,
            filename,
            verbose=False,
            input_names=['state'],
            output_names=['control'],
            dynamic_axes={'state': {0: 'batch'}, 'control': {0: 'batch'}}
        )
        print(f"[NPE] Modelo exportado para {filename}")

# ==========================================
# TREINADOR DA REDE NEURAL
# ==========================================

class NPETrainer:
    """
    Treina a rede neural para clonar o MPC
    """
    
    def __init__(self, 
                 model: NeuralPredictiveEngine,
                 learning_rate: float = 0.001):
        self.model = model
        self.optimizer = optim.Adam(model.parameters(), lr=learning_rate)
        self.criterion = nn.MSELoss()
        
        # Histórico de treino
        self.train_losses = []
        self.val_losses = []
    
    def prepare_data(self,
                    states: List[PlasmaState],
                    actuators: List[ControlActuators],
                    geometry: TokamakGeometry,
                    magnetic: MagneticConfiguration) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Prepara dados de treino
        
        Args:
            states: Lista de estados do plasma
            actuators: Lista de atuadores correspondentes
            geometry: Geometria do tokamak
            magnetic: Configuração magnética
        
        Returns:
            (X_tensor, Y_tensor)
        """
        X = []
        Y = []
        
        for state, act in zip(states, actuators):
            # Entrada: estado + parâmetros derivados
            q95 = DimensionlessParameters.safety_factor_q95(geometry, magnetic)
            beta_N = DimensionlessParameters.normalized_beta(state, geometry, magnetic)
            
            x = np.array([
                state.T_e,
                state.T_i,
                state.n_e / 1e20,  # Normaliza
                state.n_i / 1e20,
                state.Z,
                state.Z_dot,
                state.l_i,
                q95,
                beta_N,
                state.Z_eff
            ])
            
            # Saída: ações de controle
            y = np.array([
                act.P_NBI,
                act.P_ECRH,
                act.P_ICRH,
                act.F_z
            ])
            
            X.append(x)
            Y.append(y)
        
        X_array = np.array(X)
        Y_array = np.array(Y)
        
        # Calcula normalização
        input_mean = X_array.mean(axis=0)
        input_std = X_array.std(axis=0)
        output_mean = Y_array.mean(axis=0)
        output_std = Y_array.std(axis=0)
        
        # Define normalização no modelo
        self.model.set_normalization(input_mean, input_std, output_mean, output_std)
        
        # Converte para tensors
        X_tensor = torch.tensor(X_array, dtype=torch.float32)
        Y_tensor = torch.tensor(Y_array, dtype=torch.float32)
        
        return X_tensor, Y_tensor
    
    def train(self,
             X_train: torch.Tensor,
             Y_train: torch.Tensor,
             X_val: Optional[torch.Tensor] = None,
             Y_val: Optional[torch.Tensor] = None,
             epochs: int = 100,
             batch_size: int = 32,
             verbose: bool = True):
        """
        Treina a rede neural
        
        Args:
            X_train: Dados de entrada de treino
            Y_train: Dados de saída de treino
            X_val: Dados de validação (opcional)
            Y_val: Saídas de validação (opcional)
            epochs: Número de épocas
            batch_size: Tamanho do batch
            verbose: Imprimir progresso
        """
        n_samples = X_train.shape[0]
        n_batches = n_samples // batch_size
        
        if verbose:
            print("=" * 70)
            print("TREINAMENTO DA REDE NEURAL NPE")
            print("=" * 70)
            print(f"Amostras de treino: {n_samples}")
            print(f"Épocas: {epochs}")
            print(f"Batch size: {batch_size}")
            print("=" * 70)
        
        for epoch in range(epochs):
            self.model.train()
            epoch_loss = 0.0
            
            # Embaralha dados
            perm = torch.randperm(n_samples)
            X_shuffled = X_train[perm]
            Y_shuffled = Y_train[perm]
            
            # Loop de batches
            for i in range(n_batches):
                start = i * batch_size
                end = start + batch_size
                
                X_batch = X_shuffled[start:end]
                Y_batch = Y_shuffled[start:end]
                
                # Forward
                self.optimizer.zero_grad()
                Y_pred = self.model(X_batch)
                loss = self.criterion(Y_pred, Y_batch)
                
                # Backward
                loss.backward()
                self.optimizer.step()
                
                epoch_loss += loss.item()
            
            # Média da época
            avg_loss = epoch_loss / n_batches
            self.train_losses.append(avg_loss)
            
            # Validação
            if X_val is not None and Y_val is not None:
                self.model.eval()
                with torch.no_grad():
                    Y_val_pred = self.model(X_val)
                    val_loss = self.criterion(Y_val_pred, Y_val).item()
                    self.val_losses.append(val_loss)
            
            # Imprime progresso
            if verbose and (epoch + 1) % 10 == 0:
                if X_val is not None:
                    print(f"Época {epoch+1}/{epochs} | "
                          f"Loss Treino: {avg_loss:.6f} | "
                          f"Loss Val: {val_loss:.6f}")
                else:
                    print(f"Época {epoch+1}/{epochs} | Loss: {avg_loss:.6f}")
        
        if verbose:
            print("=" * 70)
            print("TREINO CONCLUÍDO ✓")
            print("=" * 70)
    
    def save_model(self, filepath: str):
        """Salva modelo treinado"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'train_losses': self.train_losses,
            'val_losses': self.val_losses
        }, filepath)
        print(f"[NPE] Modelo salvo em {filepath}")
    
    def load_model(self, filepath: str):
        """Carrega modelo treinado"""
        checkpoint = torch.load(filepath)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.train_losses = checkpoint['train_losses']
        self.val_losses = checkpoint['val_losses']
        print(f"[NPE] Modelo carregado de {filepath}")

# ==========================================
# CONTROLADOR NEURAL
# ==========================================

class NeuralController:
    """
    Controlador que usa a rede neural treinada
    """
    
    def __init__(self,
                 model: NeuralPredictiveEngine,
                 geometry: TokamakGeometry,
                 magnetic: MagneticConfiguration):
        self.model = model
        self.geometry = geometry
        self.magnetic = magnetic
        self.model.eval()
    
    def compute_control(self, state: PlasmaState) -> ControlActuators:
        """
        Calcula controle usando a rede neural
        
        Args:
            state: Estado atual do plasma
        
        Returns:
            Atuadores de controle
        """
        # Prepara entrada
        q95 = DimensionlessParameters.safety_factor_q95(self.geometry, self.magnetic)
        beta_N = DimensionlessParameters.normalized_beta(state, self.geometry, self.magnetic)
        
        x = np.array([
            state.T_e,
            state.T_i,
            state.n_e / 1e20,
            state.n_i / 1e20,
            state.Z,
            state.Z_dot,
            state.l_i,
            q95,
            beta_N,
            state.Z_eff
        ])
        
        # Inferência
        with torch.no_grad():
            x_tensor = torch.tensor(x, dtype=torch.float32).unsqueeze(0)
            y_tensor = self.model(x_tensor)
            y = y_tensor.squeeze(0).numpy()
        
        # Converte para atuadores
        return ControlActuators(
            P_NBI=float(np.clip(y[0], 0, 33)),
            P_ECRH=float(np.clip(y[1], 0, 20)),
            P_ICRH=float(np.clip(y[2], 0, 20)),
            F_z=float(np.clip(y[3], -5, 5))
        )

# ==========================================
# TESTE
# ==========================================

if __name__ == "__main__":
    print("=" * 70)
    print("TESTE DA REDE NEURAL NPE")
    print("=" * 70)
    
    # Criar modelo
    model = NeuralPredictiveEngine(
        input_dim=10,
        hidden_dims=[64, 64, 32],
        output_dim=4
    )
    
    print(f"\nArquitetura da Rede:")
    print(model)
    
    # Teste de forward pass
    x_test = torch.randn(5, 10)  # 5 amostras
    y_test = model(x_test)
    
    print(f"\nTeste de Forward Pass:")
    print(f"  Input shape: {x_test.shape}")
    print(f"  Output shape: {y_test.shape}")
    
    # Exportar para ONNX
    model.export_to_onnx("test_npe_model.onnx")
    
    print("\n" + "=" * 70)
    print("TESTE CONCLUÍDO ✓")
    print("=" * 70)
