"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Simulador Completo e Ponto de Entrada Principal

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import sys
import os
# Adiciona o diretório raiz do projeto ao path para importações relativas
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importações dos submódulos
from src.modules.fisica import *
from src.modules.integracao import *
from src.modules.controladores import *
from src.modules.seguranca import *
from src.modules.diagnosticos import *

# ==========================================
# CLASSE PRINCIPAL DO SIMULADOR
# ==========================================

class NPEPSQSimulator(TokamakSimulator):
    """
    Simulador completo que integra física, integração, controle e segurança.
    """
    
    def __init__(self, config: TokamakConfiguration):
        super().__init__(config)
        
        # Inicializa sistemas de controle e segurança
        self.mpc_controller = MPCController(config.geometry, config.magnetic, MPCConfig())
        self.psq_system = PlasmaStabilityQuenching()
        
        # O controlador neural deve ser carregado separadamente
        self.neural_controller = None
        
        # Sistema integrado NPE-PSQ
        self.integrated_controller = None
    
    def load_neural_controller(self, weights_path: str = "npe_weights.pth"):
        """Carrega o modelo neural treinado."""
        model = NeuralPredictiveEngine()
        try:
            model.load_state_dict(torch.load(weights_path))
            self.neural_controller = NeuralController(model, self.config.geometry, self.config.magnetic)
            self.integrated_controller = IntegratedNPEPSQ(
                self.neural_controller,
                self.psq_system,
                self.config.geometry,
                self.config.magnetic
            )
            print(f"[NPE] Controlador Neural carregado com sucesso de {weights_path}")
        except FileNotFoundError:
            print(f"[ERRO] Arquivo de pesos '{weights_path}' não encontrado. O controlador neural não será usado.")
            self.neural_controller = None
            self.integrated_controller = None
    
    def run_simulation(self, t_end: float, control_mode: str = "fixed", mpc_config: Optional[MPCConfig] = None):
        """
        Executa a simulação com o modo de controle especificado.
        
        Args:
            t_end: Tempo final da simulação [s]
            control_mode: "fixed", "mpc", "neural"
            mpc_config: Configuração do MPC (se control_mode="mpc")
        
        Returns:
            Histórico da simulação
        """
        print(f"\n[SIMULAÇÃO] Iniciando simulação em modo: {control_mode.upper()}")
        
        if control_mode == "fixed":
            # Modo de aquecimento fixo (sem controle)
            actuators = ControlActuators(P_NBI=20.0, P_ECRH=10.0, P_ICRH=15.0)
            return self.simulate(t_end=t_end, actuators=actuators)
        
        elif control_mode == "mpc":
            if mpc_config:
                self.mpc_controller = MPCController(self.config.geometry, self.config.magnetic, mpc_config)
            
            def mpc_control_function(state, t):
                return self.mpc_controller.compute_control(state)
            
            return self.simulate(t_end=t_end, actuators=ControlActuators(), controller=mpc_control_function)
        
        elif control_mode == "neural":
            if not self.integrated_controller:
                print("[ERRO] Controlador Neural não carregado. Tentando carregar...")
                self.load_neural_controller()
                if not self.integrated_controller:
                    print("[ERRO] Falha ao carregar. Usando controle fixo.")
                    return self.run_simulation(t_end, "fixed")
            
            def neural_control_function(state, t):
                actuators, is_safe, msg = self.integrated_controller.compute_safe_control(state)
                if not is_safe:
                    print(f"[PSQ ALERTA @ t={t:.2f}s] {msg}")
                return actuators
            
            return self.simulate(t_end=t_end, actuators=ControlActuators(), controller=neural_control_function)
        
        else:
            raise ValueError(f"Modo de controle '{control_mode}' inválido.")

# ==========================================
# EXEMPLO DE USO
# ==========================================

if __name__ == "__main__":
    print("=" * 70)
    print("NPE-PSQ ADVANCED TOKAMAK SIMULATOR - DEMO")
    print("=" * 70)
    
    # 1. Configuração
    config = create_iter_like_config()
    config.print_summary()
    
    # 2. Inicialização do Simulador
    simulator = NPEPSQSimulator(config)
    
    # 3. Simulação Básica (Modo Fixo)
    print("\n--- Simulação 1: Modo Fixo (30s) ---")
    history_fixed = simulator.run_simulation(t_end=30.0, control_mode="fixed")
    
    # 4. Diagnósticos e Plot
    final_state_fixed = simulator.get_final_state()
    diagnostics_fixed = calculate_diagnostics(final_state_fixed, config.geometry, config.magnetic)
    print_summary(diagnostics_fixed)
    plot_history(history_fixed, config, filename="fixed_simulation_results.png")
    
    # 5. Simulação com MPC (Modo MPC)
    print("\n--- Simulação 2: Modo MPC (20s) ---")
    mpc_conf = MPCConfig(T_e_ref=12.0, Z_ref=0.0)
    history_mpc = simulator.run_simulation(t_end=20.0, control_mode="mpc", mpc_config=mpc_conf)
    
    # 6. Diagnósticos e Plot
    final_state_mpc = simulator.get_final_state()
    diagnostics_mpc = calculate_diagnostics(final_state_mpc, config.geometry, config.magnetic)
    print_summary(diagnostics_mpc)
    plot_history(history_mpc, config, filename="mpc_simulation_results.png")
    
    print("\n" + "=" * 70)
    print("DEMONSTRAÇÃO CONCLUÍDA. Verifique a pasta 'assets' para os gráficos.")
    print("=" * 70)
