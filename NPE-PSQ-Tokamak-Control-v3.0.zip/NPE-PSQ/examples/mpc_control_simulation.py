"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Exemplo: Simulação com Controlador MPC

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import sys
sys.path.append('/home/ubuntu/npe-psq-advanced')

import numpy as np
import matplotlib.pyplot as plt
from src.tokamak_config import *
from src.numerical_integration import *
from src.mpc_controller import *
from src.plasma_dynamics import *

def main():
    print("=" * 70)
    print("NPE-PSQ ADVANCED - SIMULAÇÃO COM CONTROLE MPC")
    print("=" * 70)
    
    # Configuração
    print("\n[1/5] Configurando tokamak...")
    config = create_iter_like_config()
    
    # Estado inicial abaixo da referência
    config.state.T_e = 6.0
    config.state.T_i = 6.0
    config.state.Z = 0.03  # Deslocamento vertical inicial
    
    print(f"  Estado Inicial:")
    print(f"    T_e = {config.state.T_e:.1f} keV")
    print(f"    T_i = {config.state.T_i:.1f} keV")
    print(f"    Z = {config.state.Z:.3f} m")
    
    # Configuração do MPC
    print("\n[2/5] Configurando controlador MPC...")
    mpc_config = MPCConfig(
        N=15,           # Horizonte de predição
        T_e_ref=10.0,   # Referência de temperatura
        T_i_ref=10.0,
        Z_ref=0.0,      # Referência de posição
        dt=0.1
    )
    
    print(f"  Horizonte de Predição: {mpc_config.N}")
    print(f"  Setpoint T_e: {mpc_config.T_e_ref:.1f} keV")
    print(f"  Setpoint Z: {mpc_config.Z_ref:.3f} m")
    
    # Criar controlador
    controller = MPCController(
        config.geometry,
        config.magnetic,
        mpc_config
    )
    
    # Criar simulador
    print("\n[3/5] Criando simulador...")
    simulator = TokamakSimulator(config)
    
    # Função de controle MPC
    def mpc_control_function(state, t):
        """Função de controle que chama o MPC"""
        return controller.compute_control(state)
    
    # Executar simulação
    print("\n[4/5] Executando simulação com MPC (20 segundos)...")
    t_end = 20.0
    
    history = simulator.simulate(
        t_end=t_end,
        actuators=ControlActuators(),  # Inicial zerado
        controller=mpc_control_function
    )
    
    # Resultados
    final_state = simulator.get_final_state()
    
    print("\n" + "=" * 70)
    print("RESULTADOS DA SIMULAÇÃO MPC")
    print("=" * 70)
    print(f"\nEstado Final (t={t_end}s):")
    print(f"  T_e: {final_state.T_e:.2f} keV (ref: {mpc_config.T_e_ref:.2f})")
    print(f"  T_i: {final_state.T_i:.2f} keV (ref: {mpc_config.T_i_ref:.2f})")
    print(f"  Z: {final_state.Z:.4f} m (ref: {mpc_config.Z_ref:.4f})")
    
    # Erro de tracking
    error_T_e = abs(final_state.T_e - mpc_config.T_e_ref)
    error_Z = abs(final_state.Z - mpc_config.Z_ref)
    
    print(f"\nErro de Tracking:")
    print(f"  Erro T_e: {error_T_e:.3f} keV ({error_T_e/mpc_config.T_e_ref*100:.1f}%)")
    print(f"  Erro Z: {error_Z*100:.2f} cm")
    
    # Estatísticas
    simulator.print_statistics()
    
    # Plotar
    print("\n[5/5] Gerando gráficos...")
    plot_mpc_results(history, config, mpc_config)
    
    print("\n" + "=" * 70)
    print("✓ SIMULAÇÃO MPC CONCLUÍDA COM SUCESSO!")
    print("=" * 70)

def plot_mpc_results(history, config, mpc_config):
    """Plota resultados da simulação MPC"""
    time = history['time']
    states = history['state']
    actuators = history['actuators']
    
    # Extrai variáveis
    T_e = states[:, 0]
    T_i = states[:, 1]
    Z = states[:, 4]
    
    P_NBI = actuators[:, 0]
    P_ECRH = actuators[:, 1]
    P_ICRH = actuators[:, 2]
    F_z = actuators[:, 3]
    
    # Criar figura
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('NPE-PSQ MPC Controller - Resultados', fontsize=16, fontweight='bold')
    
    # Temperatura eletrônica
    axes[0, 0].plot(time, T_e, 'r-', linewidth=2, label='T_e')
    axes[0, 0].axhline(y=mpc_config.T_e_ref, color='k', linestyle='--', linewidth=1.5, label='Referência')
    axes[0, 0].fill_between(time, mpc_config.T_e_ref - 0.5, mpc_config.T_e_ref + 0.5, 
                            alpha=0.2, color='gray', label='Banda de tolerância')
    axes[0, 0].set_xlabel('Tempo [s]')
    axes[0, 0].set_ylabel('Temperatura [keV]')
    axes[0, 0].set_title('Controle de Temperatura Eletrônica')
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)
    
    # Posição vertical
    axes[0, 1].plot(time, Z * 100, 'm-', linewidth=2, label='Z')
    axes[0, 1].axhline(y=mpc_config.Z_ref * 100, color='k', linestyle='--', linewidth=1.5, label='Referência')
    axes[0, 1].fill_between(time, -1, 1, alpha=0.2, color='gray', label='Banda de tolerância')
    axes[0, 1].set_xlabel('Tempo [s]')
    axes[0, 1].set_ylabel('Posição Vertical [cm]')
    axes[0, 1].set_title('Controle de Posição Vertical')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)
    
    # Potências de aquecimento
    axes[1, 0].plot(time, P_NBI, 'b-', linewidth=2, label='P_NBI')
    axes[1, 0].plot(time, P_ECRH, 'r-', linewidth=2, label='P_ECRH')
    axes[1, 0].plot(time, P_ICRH, 'g-', linewidth=2, label='P_ICRH')
    axes[1, 0].plot(time, P_NBI + P_ECRH + P_ICRH, 'k--', linewidth=2, label='P_total')
    axes[1, 0].set_xlabel('Tempo [s]')
    axes[1, 0].set_ylabel('Potência [MW]')
    axes[1, 0].set_title('Ações de Controle - Aquecimento')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)
    
    # Força vertical
    axes[1, 1].plot(time, F_z, 'c-', linewidth=2)
    axes[1, 1].axhline(y=mpc_config.F_z_max, color='r', linestyle='--', label='Limite')
    axes[1, 1].axhline(y=-mpc_config.F_z_max, color='r', linestyle='--')
    axes[1, 1].set_xlabel('Tempo [s]')
    axes[1, 1].set_ylabel('Força [MN]')
    axes[1, 1].set_title('Ação de Controle - Força Vertical')
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/npe-psq-advanced/mpc_control_results.png', dpi=150, bbox_inches='tight')
    print("  ✓ Gráficos salvos em: mpc_control_results.png")

if __name__ == "__main__":
    main()
