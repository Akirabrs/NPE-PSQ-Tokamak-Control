"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Exemplo: Simulação Básica

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import sys
sys.path.append('/home/ubuntu/npe-psq-advanced')

import numpy as np
import matplotlib.pyplot as plt
from src.tokamak_config import *
from src.numerical_integration import *
from src.plasma_dynamics import *

def main():
    print("=" * 70)
    print("NPE-PSQ ADVANCED TOKAMAK SIMULATOR - SIMULAÇÃO BÁSICA")
    print("=" * 70)
    
    # [1/4] Configurar tokamak
    print("\n[1/4] Configurando tokamak...")
    config = create_iter_like_config()
    config.print_summary()
    
    # [2/4] Criar simulador
    print("\n[2/4] Criando simulador...")
    simulator = TokamakSimulator(config)
    
    # [3/4] Definir atuadores
    print("\n[3/4] Definindo atuadores de controle...")
    actuators = ControlActuators(
        P_NBI=20.0,   # 20 MW
        P_ECRH=10.0,  # 10 MW
        P_ICRH=15.0,  # 15 MW
        F_z=0.0       # Sem força vertical
    )
    
    print(f"  P_NBI:  {actuators.P_NBI:.1f} MW")
    print(f"  P_ECRH: {actuators.P_ECRH:.1f} MW")
    print(f"  P_ICRH: {actuators.P_ICRH:.1f} MW")
    print(f"  P_total: {actuators.total_heating_power():.1f} MW")
    
    # [4/4] Executar simulação
    print("\n[4/4] Executando simulação de 30 segundos...")
    t_end = 30.0  # segundos
    
    history = simulator.simulate(t_end=t_end, actuators=actuators)
    
    # Estado final
    final_state = simulator.get_final_state()
    
    print("\n" + "=" * 70)
    print("RESULTADOS DA SIMULAÇÃO")
    print("=" * 70)
    print(f"\nEstado Final (t={t_end}s):")
    print(f"  Temperatura Eletrônica:  {final_state.T_e:.2f} keV")
    print(f"  Temperatura Iônica:      {final_state.T_i:.2f} keV")
    print(f"  Densidade Eletrônica:    {final_state.n_e:.2e} m⁻³")
    print(f"  Posição Vertical:        {final_state.Z:.4f} m")
    
    # Diagnósticos
    print("\nDiagnósticos:")
    q95 = DimensionlessParameters.safety_factor_q95(config.geometry, config.magnetic)
    beta_N = DimensionlessParameters.normalized_beta(final_state, config.geometry, config.magnetic)
    f_GW = DimensionlessParameters.greenwald_fraction(final_state, config.geometry, config.magnetic)
    P_fus = FusionPower.total_fusion_power(final_state, config.geometry)
    
    print(f"  Fator de Segurança (q95): {q95:.2f}")
    print(f"  Beta Normalizado (β_N):   {beta_N:.2f}")
    print(f"  Fração de Greenwald:      {f_GW:.2%}")
    print(f"  Potência de Fusão:        {P_fus:.2f} MW")
    
    # Estatísticas de integração
    simulator.print_statistics()
    
    # Plotar resultados
    print("\n[5/5] Gerando gráficos...")
    plot_results(history, config)
    
    print("\n" + "=" * 70)
    print("✓ SIMULAÇÃO CONCLUÍDA COM SUCESSO!")
    print("=" * 70)

def plot_results(history, config):
    """
    Plota resultados da simulação
    
    Args:
        history: Histórico da simulação
        config: Configuração do tokamak
    """
    time = history['time']
    states = history['state']
    
    # Extrai variáveis
    T_e = states[:, 0]
    T_i = states[:, 1]
    n_e = states[:, 2]
    Z = states[:, 4]
    
    # Calcula diagnósticos ao longo do tempo
    q95_history = []
    beta_N_history = []
    P_fus_history = []
    
    for state_vec in states:
        state = PlasmaState.from_vector(state_vec)
        
        q95 = DimensionlessParameters.safety_factor_q95(config.geometry, config.magnetic)
        beta_N = DimensionlessParameters.normalized_beta(state, config.geometry, config.magnetic)
        P_fus = FusionPower.total_fusion_power(state, config.geometry)
        
        q95_history.append(q95)
        beta_N_history.append(beta_N)
        P_fus_history.append(P_fus)
    
    # Criar figura
    fig, axes = plt.subplots(3, 2, figsize=(14, 10))
    fig.suptitle('NPE-PSQ Tokamak Simulator - Resultados da Simulação', fontsize=16, fontweight='bold')
    
    # Temperatura
    axes[0, 0].plot(time, T_e, 'r-', linewidth=2, label='T_e')
    axes[0, 0].plot(time, T_i, 'b-', linewidth=2, label='T_i')
    axes[0, 0].set_xlabel('Tempo [s]')
    axes[0, 0].set_ylabel('Temperatura [keV]')
    axes[0, 0].set_title('Evolução da Temperatura')
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)
    
    # Densidade
    axes[0, 1].plot(time, n_e / 1e20, 'g-', linewidth=2)
    axes[0, 1].set_xlabel('Tempo [s]')
    axes[0, 1].set_ylabel('Densidade [10²⁰ m⁻³]')
    axes[0, 1].set_title('Densidade Eletrônica')
    axes[0, 1].grid(True, alpha=0.3)
    
    # Posição vertical
    axes[1, 0].plot(time, Z * 100, 'm-', linewidth=2)
    axes[1, 0].axhline(y=10, color='r', linestyle='--', label='Limite (10 cm)')
    axes[1, 0].axhline(y=-10, color='r', linestyle='--')
    axes[1, 0].set_xlabel('Tempo [s]')
    axes[1, 0].set_ylabel('Posição Vertical [cm]')
    axes[1, 0].set_title('Controle de Posição Vertical')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)
    
    # Fator de segurança
    axes[1, 1].plot(time, q95_history, 'c-', linewidth=2)
    axes[1, 1].axhline(y=2.0, color='r', linestyle='--', label='Limite mínimo')
    axes[1, 1].set_xlabel('Tempo [s]')
    axes[1, 1].set_ylabel('q95')
    axes[1, 1].set_title('Fator de Segurança')
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)
    
    # Beta normalizado
    axes[2, 0].plot(time, beta_N_history, 'orange', linewidth=2)
    axes[2, 0].axhline(y=3.5, color='r', linestyle='--', label='Limite')
    axes[2, 0].set_xlabel('Tempo [s]')
    axes[2, 0].set_ylabel('β_N')
    axes[2, 0].set_title('Beta Normalizado')
    axes[2, 0].legend()
    axes[2, 0].grid(True, alpha=0.3)
    
    # Potência de fusão
    axes[2, 1].plot(time, P_fus_history, 'purple', linewidth=2)
    axes[2, 1].set_xlabel('Tempo [s]')
    axes[2, 1].set_ylabel('Potência [MW]')
    axes[2, 1].set_title('Potência de Fusão')
    axes[2, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/npe-psq-advanced/basic_simulation_results.png', dpi=150, bbox_inches='tight')
    print("  ✓ Gráficos salvos em: basic_simulation_results.png")
    
    # Não mostra interativamente (modo headless)
    # plt.show()

if __name__ == "__main__":
    main()
