"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Neural Predictive Engine & Plasma Stability Quenching

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

__version__ = "3.0.0"
__author__ = "Guilherme Brasil de Souza"

# Importações principais (lazy loading para evitar problemas de dependências)
# from src.constants import *
# from src.tokamak_config import *
# from src.plasma_dynamics import *
# from src.numerical_integration import *
# from src.mpc_controller import *
# from src.neural_controller import *
# from src.safety_system import *

__all__ = [
    # Constantes
    'ELEMENTARY_CHARGE',
    'ELECTRON_MASS',
    'BOLTZMANN_CONSTANT',
    
    # Configuração
    'TokamakGeometry',
    'MagneticConfiguration',
    'PlasmaState',
    'ControlActuators',
    'TokamakConfiguration',
    'create_iter_like_config',
    'create_compact_config',
    
    # Dinâmica
    'PlasmaProfiles',
    'FusionPower',
    'PowerLosses',
    'DimensionlessParameters',
    'MHDInstabilities',
    'PlasmaEvolution',
    
    # Integração
    'RK4Integrator',
    'TokamakDerivatives',
    'TokamakSimulator',
    
    # Controladores
    'MPCConfig',
    'MPCController',
    'NeuralPredictiveEngine',
    'NPETrainer',
    'NeuralController',
    
    # Segurança
    'SafetyLimits',
    'SafetyActionCode',
    'PlasmaStabilityQuenching',
    'IntegratedNPEPSQ',
]
