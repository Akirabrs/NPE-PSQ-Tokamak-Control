"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Neural Predictive Engine (NPE): Rede Neural para Controle Rápido

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import Optional, List, Tuple
from src.tokamak_config import *
from src.mpc_controller import *

# ==========================================
# ARQUITETURA DA REDE NEURAL
# ==========================================

class NeuralPredictiveEngine(nn.Module):
    """
    Rede Neural que clona o comportamento do MPC
    
    Arquitetura: MLP otimizado para FPGA
    Input: Estado do plasma (10 dimensões)
    Output: Ações de controle (4 dimensões)
    """
    
    def __init__(self, 
                 input_dim: int = 10,
                 hidden_dims: List[int] = [64, 64, 32],
                 output_dim: int = 4):
        super(NeuralPredictiveEngine, self).__init__()
        
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Camadas
        layers = []
        
        # Primeira camada
        layers.append(nn.Linear(input_dim, hidden_dims[0]))
        layers.append(nn.BatchNorm1d(hidden_dims[0]))
        layers.append(nn.ReLU())
        
        # Camadas intermediárias
        for i in range(len(hidden_dims) - 1):
            layers.append(nn.Linear(hidden_dims[i], hidden_dims[i+1]))
            layers.append(nn.BatchNorm1d(hidden_dims[i+1]))
            layers.append(nn.ReLU())
        
        # Camada de saída
        layers.append(nn.Linear(hidden_dims[-1], output_dim))
        
        self.network = nn.Sequential(*layers)
        
        # Normalização de entrada/saída (aprendida durante treino)
        self.register_buffer('input_mean', torch.zeros(input_dim))
        self.register_buffer('input_std', torch.ones(input_dim))
        self.register_buffer('output_mean', torch.zeros(output_dim))
        self.register_buffer('output_std', torch.ones(output_dim))
    
    def forward(self, x):
        """
        Forward pass
        
        Args:
            x: Tensor de entrada [batch, input_dim]
        
        Returns:
            Tensor de saída [batch, output_dim]
        """
        # Normaliza entrada
        x_norm = (x - self.input_mean) / (self.input_std + 1e-8)
        
        # Passa pela rede
        y_norm = self.network(x_norm)
        
        # Desnormaliza saída
        y = y_norm * self.output_std + self.output_mean
        
        return y
    
    def set_normalization(self, 
                         input_mean: np.ndarray,
                         input_std: np.ndarray,
                         output_mean: np.ndarray,
                         output_std: np.ndarray):
        """
        Define parâmetros de normalização
        
        Args:
            input_mean: Média das entradas
            input_std: Desvio padrão das entradas
            output_mean: Média das saídas
            output_std: Desvio padrão das saídas
        """
        self.input_mean = torch.tensor(input_mean, dtype=torch.float32)
        self.input_std = torch.tensor(input_std, dtype=torch.float32)
        self.output_mean = torch.tensor(output_mean, dtype=torch.float32)
        self.output_std = torch.tensor(output_std, dtype=torch.float32)
    
    def export_to_onnx(self, filename: str = "npe_model.onnx"):
        """
        Exporta modelo para formato ONNX (compatível com FPGA)
        
        Args:
            filename: Nome do arquivo de saída
        """
        dummy_input = torch.randn(1, self.input_dim)
        torch.onnx.export(
            self,
            dummy_input,
            filename,
            verbose=False,
            input_names=['state'],
            output_names=['control'],
            dynamic_axes={'state': {0: 'batch'}, 'control': {0: 'batch'}}
        )
        print(f"[NPE] Modelo exportado para {filename}")

# ==========================================
# TREINADOR DA REDE NEURAL
# ==========================================

class NPETrainer:
    """
    Treina a rede neural para clonar o MPC
    """
    
    def __init__(self, 
                 model: NeuralPredictiveEngine,
                 learning_rate: float = 0.001):
        self.model = model
        self.optimizer = optim.Adam(model.parameters(), lr=learning_rate)
        self.criterion = nn.MSELoss()
        
        # Histórico de treino
        self.train_losses = []
        self.val_losses = []
    
    def prepare_data(self,
                    states: List[PlasmaState],
                    actuators: List[ControlActuators],
                    geometry: TokamakGeometry,
                    magnetic: MagneticConfiguration) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Prepara dados de treino
        
        Args:
            states: Lista de estados do plasma
            actuators: Lista de atuadores correspondentes
            geometry: Geometria do tokamak
            magnetic: Configuração magnética
        
        Returns:
            (X_tensor, Y_tensor)
        """
        X = []
        Y = []
        
        for state, act in zip(states, actuators):
            # Entrada: estado + parâmetros derivados
            q95 = DimensionlessParameters.safety_factor_q95(geometry, magnetic)
            beta_N = DimensionlessParameters.normalized_beta(state, geometry, magnetic)
            
            x = np.array([
                state.T_e,
                state.T_i,
                state.n_e / 1e20,  # Normaliza
                state.n_i / 1e20,
                state.Z,
                state.Z_dot,
                state.l_i,
                q95,
                beta_N,
                state.Z_eff
            ])
            
            # Saída: ações de controle
            y = np.array([
                act.P_NBI,
                act.P_ECRH,
                act.P_ICRH,
                act.F_z
            ])
            
            X.append(x)
            Y.append(y)
        
        X_array = np.array(X)
        Y_array = np.array(Y)
        
        # Calcula normalização
        input_mean = X_array.mean(axis=0)
        input_std = X_array.std(axis=0)
        output_mean = Y_array.mean(axis=0)
        output_std = Y_array.std(axis=0)
        
        # Define normalização no modelo
        self.model.set_normalization(input_mean, input_std, output_mean, output_std)
        
        # Converte para tensors
        X_tensor = torch.tensor(X_array, dtype=torch.float32)
        Y_tensor = torch.tensor(Y_array, dtype=torch.float32)
        
        return X_tensor, Y_tensor
    
    def train(self,
             X_train: torch.Tensor,
             Y_train: torch.Tensor,
             X_val: Optional[torch.Tensor] = None,
             Y_val: Optional[torch.Tensor] = None,
             epochs: int = 100,
             batch_size: int = 32,
             verbose: bool = True):
        """
        Treina a rede neural
        
        Args:
            X_train: Dados de entrada de treino
            Y_train: Dados de saída de treino
            X_val: Dados de validação (opcional)
            Y_val: Saídas de validação (opcional)
            epochs: Número de épocas
            batch_size: Tamanho do batch
            verbose: Imprimir progresso
        """
        n_samples = X_train.shape[0]
        n_batches = n_samples // batch_size
        
        if verbose:
            print("=" * 70)
            print("TREINAMENTO DA REDE NEURAL NPE")
            print("=" * 70)
            print(f"Amostras de treino: {n_samples}")
            print(f"Épocas: {epochs}")
            print(f"Batch size: {batch_size}")
            print("=" * 70)
        
        for epoch in range(epochs):
            self.model.train()
            epoch_loss = 0.0
            
            # Embaralha dados
            perm = torch.randperm(n_samples)
            X_shuffled = X_train[perm]
            Y_shuffled = Y_train[perm]
            
            # Loop de batches
            for i in range(n_batches):
                start = i * batch_size
                end = start + batch_size
                
                X_batch = X_shuffled[start:end]
                Y_batch = Y_shuffled[start:end]
                
                # Forward
                self.optimizer.zero_grad()
                Y_pred = self.model(X_batch)
                loss = self.criterion(Y_pred, Y_batch)
                
                # Backward
                loss.backward()
                self.optimizer.step()
                
                epoch_loss += loss.item()
            
            # Média da época
            avg_loss = epoch_loss / n_batches
            self.train_losses.append(avg_loss)
            
            # Validação
            if X_val is not None and Y_val is not None:
                self.model.eval()
                with torch.no_grad():
                    Y_val_pred = self.model(X_val)
                    val_loss = self.criterion(Y_val_pred, Y_val).item()
                    self.val_losses.append(val_loss)
            
            # Imprime progresso
            if verbose and (epoch + 1) % 10 == 0:
                if X_val is not None:
                    print(f"Época {epoch+1}/{epochs} | "
                          f"Loss Treino: {avg_loss:.6f} | "
                          f"Loss Val: {val_loss:.6f}")
                else:
                    print(f"Época {epoch+1}/{epochs} | Loss: {avg_loss:.6f}")
        
        if verbose:
            print("=" * 70)
            print("TREINO CONCLUÍDO ✓")
            print("=" * 70)
    
    def save_model(self, filepath: str):
        """Salva modelo treinado"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'train_losses': self.train_losses,
            'val_losses': self.val_losses
        }, filepath)
        print(f"[NPE] Modelo salvo em {filepath}")
    
    def load_model(self, filepath: str):
        """Carrega modelo treinado"""
        checkpoint = torch.load(filepath)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.train_losses = checkpoint['train_losses']
        self.val_losses = checkpoint['val_losses']
        print(f"[NPE] Modelo carregado de {filepath}")

# ==========================================
# CONTROLADOR NEURAL
# ==========================================

class NeuralController:
    """
    Controlador que usa a rede neural treinada
    """
    
    def __init__(self,
                 model: NeuralPredictiveEngine,
                 geometry: TokamakGeometry,
                 magnetic: MagneticConfiguration):
        self.model = model
        self.geometry = geometry
        self.magnetic = magnetic
        self.model.eval()
    
    def compute_control(self, state: PlasmaState) -> ControlActuators:
        """
        Calcula controle usando a rede neural
        
        Args:
            state: Estado atual do plasma
        
        Returns:
            Atuadores de controle
        """
        # Prepara entrada
        q95 = DimensionlessParameters.safety_factor_q95(self.geometry, self.magnetic)
        beta_N = DimensionlessParameters.normalized_beta(state, self.geometry, self.magnetic)
        
        x = np.array([
            state.T_e,
            state.T_i,
            state.n_e / 1e20,
            state.n_i / 1e20,
            state.Z,
            state.Z_dot,
            state.l_i,
            q95,
            beta_N,
            state.Z_eff
        ])
        
        # Inferência
        with torch.no_grad():
            x_tensor = torch.tensor(x, dtype=torch.float32).unsqueeze(0)
            y_tensor = self.model(x_tensor)
            y = y_tensor.squeeze(0).numpy()
        
        # Converte para atuadores
        return ControlActuators(
            P_NBI=float(np.clip(y[0], 0, 33)),
            P_ECRH=float(np.clip(y[1], 0, 20)),
            P_ICRH=float(np.clip(y[2], 0, 20)),
            F_z=float(np.clip(y[3], -5, 5))
        )

# ==========================================
# TESTE
# ==========================================

if __name__ == "__main__":
    print("=" * 70)
    print("TESTE DA REDE NEURAL NPE")
    print("=" * 70)
    
    # Criar modelo
    model = NeuralPredictiveEngine(
        input_dim=10,
        hidden_dims=[64, 64, 32],
        output_dim=4
    )
    
    print(f"\nArquitetura da Rede:")
    print(model)
    
    # Teste de forward pass
    x_test = torch.randn(5, 10)  # 5 amostras
    y_test = model(x_test)
    
    print(f"\nTeste de Forward Pass:")
    print(f"  Input shape: {x_test.shape}")
    print(f"  Output shape: {y_test.shape}")
    
    # Exportar para ONNX
    model.export_to_onnx("test_npe_model.onnx")
    
    print("\n" + "=" * 70)
    print("TESTE CONCLUÍDO ✓")
    print("=" * 70)
