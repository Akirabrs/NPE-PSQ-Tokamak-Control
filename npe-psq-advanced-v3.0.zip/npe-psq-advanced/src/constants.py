"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Constantes Físicas (NIST/CODATA 2018)

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import numpy as np

# ==========================================
# CONSTANTES FUNDAMENTAIS (NIST)
# ==========================================

# Carga elementar [C]
ELEMENTARY_CHARGE = 1.602176634e-19

# Massa do elétron [kg]
ELECTRON_MASS = 9.1093837015e-31

# Massa do próton [kg]
PROTON_MASS = 1.67262192369e-27

# Constante de Boltzmann [J/K]
BOLTZMANN_CONSTANT = 1.380649e-23

# Permissividade do vácuo [F/m]
EPSILON_0 = 8.8541878128e-12

# Permeabilidade do vácuo [H/m]
MU_0 = 1.25663706212e-6

# Velocidade da luz [m/s]
SPEED_OF_LIGHT = 299792458.0

# ==========================================
# CONSTANTES DERIVADAS
# ==========================================

# Massa do deutério [kg] (2.014 u)
DEUTERIUM_MASS = 2.014 * 1.66053906660e-27

# Massa do trítio [kg] (3.016 u)
TRITIUM_MASS = 3.016 * 1.66053906660e-27

# Massa da partícula alfa [kg] (4.003 u)
ALPHA_MASS = 4.003 * 1.66053906660e-27

# Energia de fusão D-T [J] (17.6 MeV)
FUSION_ENERGY_DT = 17.6e6 * ELEMENTARY_CHARGE

# Energia da partícula alfa [J] (3.5 MeV)
ALPHA_ENERGY = 3.5e6 * ELEMENTARY_CHARGE

# ==========================================
# CONVERSÕES DE UNIDADES
# ==========================================

def eV_to_J(eV):
    """Converte elétron-volts para Joules"""
    return eV * ELEMENTARY_CHARGE

def J_to_eV(J):
    """Converte Joules para elétron-volts"""
    return J / ELEMENTARY_CHARGE

def keV_to_K(keV):
    """Converte keV para Kelvin"""
    return (keV * 1e3 * ELEMENTARY_CHARGE) / BOLTZMANN_CONSTANT

def K_to_keV(K):
    """Converte Kelvin para keV"""
    return (K * BOLTZMANN_CONSTANT) / (1e3 * ELEMENTARY_CHARGE)

def MA_to_A(MA):
    """Converte Mega-Amperes para Amperes"""
    return MA * 1e6

def MW_to_W(MW):
    """Converte Mega-Watts para Watts"""
    return MW * 1e6

# ==========================================
# PARÂMETROS TÍPICOS DE TOKAMAK
# ==========================================

# Geometria ITER-like
TYPICAL_MAJOR_RADIUS = 6.2  # [m]
TYPICAL_MINOR_RADIUS = 2.0  # [m]
TYPICAL_ELONGATION = 1.7    # [-]
TYPICAL_TRIANGULARITY = 0.33  # [-]

# Campos magnéticos
TYPICAL_TOROIDAL_FIELD = 5.3  # [T]
TYPICAL_PLASMA_CURRENT = 15.0  # [MA]

# Parâmetros de plasma
TYPICAL_ELECTRON_DENSITY = 1.0e20  # [m^-3]
TYPICAL_ELECTRON_TEMP = 10.0  # [keV]
TYPICAL_ION_TEMP = 10.0  # [keV]

# Limites de segurança
GREENWALD_LIMIT_FACTOR = 1.0  # n_e / n_GW
TROYON_BETA_LIMIT = 0.028  # β_N limite
SAFETY_FACTOR_LIMIT = 2.0  # q95 mínimo

# ==========================================
# COEFICIENTES DE TRANSPORTE
# ==========================================

# Difusividade de Bohm [m^2/s]
def bohm_diffusivity(T_keV, B_T):
    """
    Calcula a difusividade de Bohm
    
    χ_Bohm = (1/16) * (k_B * T) / (e * B)
    
    Args:
        T_keV: Temperatura em keV
        B_T: Campo magnético toroidal em Tesla
    
    Returns:
        Difusividade em m^2/s
    """
    T_J = eV_to_J(T_keV * 1e3)
    return (1.0/16.0) * (T_J) / (ELEMENTARY_CHARGE * B_T)

# Coeficiente de radiação de Bremsstrahlung [W·m^3]
def bremsstrahlung_coefficient(Z_eff=1.5):
    """
    Coeficiente de radiação de Bremsstrahlung
    
    C_brem ≈ 5.35e-37 * Z_eff * sqrt(T_e) [W·m^3]
    
    Args:
        Z_eff: Carga efetiva do plasma
    
    Returns:
        Coeficiente em W·m^3
    """
    return 5.35e-37 * Z_eff

# ==========================================
# SEÇÃO DE CHOQUE DE FUSÃO D-T
# ==========================================

def fusion_cross_section_DT(T_keV):
    """
    Seção de choque de fusão D-T (Bosch-Hale 1992)
    
    Aproximação simplificada:
    - T < 1 keV: σv ≈ 1e-25 * exp(-50/T)
    - 1 < T < 10 keV: σv ≈ 1e-24 * T^2
    - 10 < T < 100 keV: σv ≈ 1e-22 (pico)
    
    Args:
        T_keV: Temperatura em keV
    
    Returns:
        <σv> em m^3/s
    """
    if T_keV < 1.0:
        return 1.0e-25 * np.exp(-50.0 / T_keV)
    elif T_keV < 10.0:
        return 1.0e-24 * T_keV**2
    elif T_keV < 100.0:
        # Fórmula de Bosch-Hale completa (simplificada)
        return 1.1e-24 * T_keV**2 / (1 + (T_keV/25.0)**3.7)**0.5
    else:
        return 1.0e-22  # Saturação

# ==========================================
# VALIDAÇÃO
# ==========================================

def validate_constants():
    """Valida as constantes contra valores conhecidos"""
    print("=" * 60)
    print("VALIDAÇÃO DE CONSTANTES FÍSICAS")
    print("=" * 60)
    
    # Teste 1: Conversão de energia
    assert abs(eV_to_J(1.0) - ELEMENTARY_CHARGE) < 1e-30
    print("✓ Conversão eV → J: OK")
    
    # Teste 2: Temperatura
    T_keV = 10.0
    T_K = keV_to_K(T_keV)
    assert abs(T_K - 1.16e8) < 1e6  # ~116 milhões de Kelvin
    print(f"✓ 10 keV = {T_K:.2e} K: OK")
    
    # Teste 3: Difusividade de Bohm
    chi_bohm = bohm_diffusivity(10.0, 5.0)
    assert 10.0 < chi_bohm < 1000.0  # Ordem de magnitude esperada (~125 m²/s)
    print(f"✓ χ_Bohm(10keV, 5T) = {chi_bohm:.4f} m²/s: OK")
    
    # Teste 4: Seção de choque de fusão
    sigma_v = fusion_cross_section_DT(15.0)
    assert 1e-23 < sigma_v < 1e-21  # Pico esperado
    print(f"✓ <σv>(15keV) = {sigma_v:.2e} m³/s: OK")
    
    print("=" * 60)
    print("TODAS AS CONSTANTES VALIDADAS ✓")
    print("=" * 60)

if __name__ == "__main__":
    validate_constants()
