"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Configuração de Geometria e Estado do Tokamak

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import numpy as np
from dataclasses import dataclass
from typing import Optional
from src.constants import *

# ==========================================
# GEOMETRIA DO TOKAMAK
# ==========================================

@dataclass
class TokamakGeometry:
    """
    Parâmetros geométricos do tokamak
    """
    R0: float  # Raio maior [m]
    a: float   # Raio menor [m]
    kappa: float  # Elongação [-]
    delta: float  # Triangularidade [-]
    
    def __post_init__(self):
        """Calcula parâmetros derivados"""
        # Volume do plasma [m^3]
        # V ≈ 2π² R0 a² κ
        self.volume = 2.0 * np.pi**2 * self.R0 * self.a**2 * self.kappa
        
        # Área da superfície [m^2]
        # A ≈ 4π² R0 a κ
        self.surface_area = 4.0 * np.pi**2 * self.R0 * self.a * self.kappa
        
        # Razão de aspecto [-]
        self.aspect_ratio = self.R0 / self.a
        
        # Comprimento da conexão magnética [m]
        # L_c ≈ 2π R0 q95
        self.connection_length = 2.0 * np.pi * self.R0
    
    def __repr__(self):
        return (f"TokamakGeometry(R0={self.R0}m, a={self.a}m, "
                f"κ={self.kappa}, δ={self.delta}, V={self.volume:.1f}m³)")

# ==========================================
# CONFIGURAÇÃO MAGNÉTICA
# ==========================================

@dataclass
class MagneticConfiguration:
    """
    Parâmetros magnéticos do tokamak
    """
    B_T: float  # Campo toroidal no eixo [T]
    I_p: float  # Corrente de plasma [MA]
    
    def __post_init__(self):
        """Valida parâmetros"""
        if self.B_T <= 0:
            raise ValueError("Campo toroidal deve ser positivo")
        if self.I_p <= 0:
            raise ValueError("Corrente de plasma deve ser positiva")
    
    def __repr__(self):
        return f"MagneticConfiguration(B_T={self.B_T}T, I_p={self.I_p}MA)"

# ==========================================
# ESTADO DO PLASMA
# ==========================================

@dataclass
class PlasmaState:
    """
    Estado termodinâmico e magnético do plasma
    """
    # Temperatura [keV]
    T_e: float  # Elétrons
    T_i: float  # Íons
    
    # Densidade [m^-3]
    n_e: float  # Elétrons
    n_i: float  # Íons
    
    # Posição vertical [m]
    Z: float = 0.0
    
    # Velocidade vertical [m/s]
    Z_dot: float = 0.0
    
    # Índice de inductância interna [-]
    l_i: float = 0.8
    
    # Potência radiativa [MW]
    P_rad: float = 0.0
    
    # Carga efetiva [-]
    Z_eff: float = 1.5
    
    def __post_init__(self):
        """Valida estado físico"""
        if self.T_e <= 0 or self.T_i <= 0:
            raise ValueError("Temperaturas devem ser positivas")
        if self.n_e <= 0 or self.n_i <= 0:
            raise ValueError("Densidades devem ser positivas")
        if self.l_i < 0.5 or self.l_i > 1.5:
            raise ValueError("l_i deve estar entre 0.5 e 1.5")
    
    def copy(self):
        """Cria uma cópia profunda do estado"""
        return PlasmaState(
            T_e=self.T_e, T_i=self.T_i,
            n_e=self.n_e, n_i=self.n_i,
            Z=self.Z, Z_dot=self.Z_dot,
            l_i=self.l_i, P_rad=self.P_rad,
            Z_eff=self.Z_eff
        )
    
    def to_vector(self):
        """Converte estado para vetor numpy (para integração numérica)"""
        return np.array([
            self.T_e, self.T_i,
            self.n_e, self.n_i,
            self.Z, self.Z_dot,
            self.l_i, self.P_rad
        ])
    
    @staticmethod
    def from_vector(vec):
        """Cria estado a partir de vetor numpy"""
        return PlasmaState(
            T_e=vec[0], T_i=vec[1],
            n_e=vec[2], n_i=vec[3],
            Z=vec[4], Z_dot=vec[5],
            l_i=vec[6], P_rad=vec[7]
        )
    
    def __repr__(self):
        return (f"PlasmaState(T_e={self.T_e:.1f}keV, T_i={self.T_i:.1f}keV, "
                f"n_e={self.n_e:.2e}m⁻³, Z={self.Z:.3f}m)")

# ==========================================
# ATUADORES DE CONTROLE
# ==========================================

@dataclass
class ControlActuators:
    """
    Potências de aquecimento e forças de controle
    """
    # Potências de aquecimento [MW]
    P_NBI: float = 0.0   # Neutral Beam Injection
    P_ECRH: float = 0.0  # Electron Cyclotron Resonance Heating
    P_ICRH: float = 0.0  # Ion Cyclotron Resonance Heating
    
    # Forças de controle vertical [MN]
    F_z: float = 0.0
    
    # Voltagens das bobinas de controle [kV]
    V_coil_upper: float = 0.0
    V_coil_lower: float = 0.0
    
    def total_heating_power(self):
        """Retorna potência total de aquecimento [MW]"""
        return self.P_NBI + self.P_ECRH + self.P_ICRH
    
    def to_vector(self):
        """Converte para vetor numpy"""
        return np.array([
            self.P_NBI, self.P_ECRH, self.P_ICRH,
            self.F_z, self.V_coil_upper, self.V_coil_lower
        ])
    
    @staticmethod
    def from_vector(vec):
        """Cria atuadores a partir de vetor"""
        return ControlActuators(
            P_NBI=vec[0], P_ECRH=vec[1], P_ICRH=vec[2],
            F_z=vec[3], V_coil_upper=vec[4], V_coil_lower=vec[5]
        )
    
    def __repr__(self):
        return (f"ControlActuators(P_total={self.total_heating_power():.1f}MW, "
                f"F_z={self.F_z:.2f}MN)")

# ==========================================
# CONFIGURAÇÃO COMPLETA DO TOKAMAK
# ==========================================

class TokamakConfiguration:
    """
    Configuração completa do tokamak (geometria + magnética + estado inicial)
    """
    def __init__(self, 
                 geometry: TokamakGeometry,
                 magnetic: MagneticConfiguration,
                 initial_state: PlasmaState):
        self.geometry = geometry
        self.magnetic = magnetic
        self.state = initial_state
        
        # Calcula parâmetros derivados
        self._compute_derived_parameters()
    
    def _compute_derived_parameters(self):
        """Calcula parâmetros derivados da configuração"""
        # Fator de segurança na borda (q95)
        # q95 ≈ (5 a² B_T) / (R0 I_p)
        self.q95 = (5.0 * self.geometry.a**2 * self.magnetic.B_T) / \
                   (self.geometry.R0 * MA_to_A(self.magnetic.I_p) * MU_0)
        
        # Limite de densidade de Greenwald [m^-3]
        # n_GW = I_p / (π a²) [10^20 m^-3]
        self.n_greenwald = (MA_to_A(self.magnetic.I_p) / 
                           (np.pi * self.geometry.a**2)) * 1e20
        
        # Beta poloidal
        # β_p ≈ (8π/μ0) * (n T) / B_p²
        self.beta_poloidal = self._calculate_beta_poloidal()
    
    def _calculate_beta_poloidal(self):
        """Calcula beta poloidal"""
        # Pressão cinética [Pa]
        p_kin = (self.state.n_e * eV_to_J(self.state.T_e * 1e3) +
                 self.state.n_i * eV_to_J(self.state.T_i * 1e3))
        
        # Campo poloidal [T]
        B_p = (MU_0 * MA_to_A(self.magnetic.I_p)) / (2.0 * np.pi * self.geometry.a)
        
        # Beta poloidal
        return (2.0 * MU_0 * p_kin) / (B_p**2)
    
    def print_summary(self):
        """Imprime sumário da configuração"""
        print("=" * 70)
        print("CONFIGURAÇÃO DO TOKAMAK NPE-PSQ")
        print("=" * 70)
        print(f"\nGEOMETRIA:")
        print(f"  Raio Maior (R0):           {self.geometry.R0:.2f} m")
        print(f"  Raio Menor (a):            {self.geometry.a:.2f} m")
        print(f"  Elongação (κ):             {self.geometry.kappa:.2f}")
        print(f"  Triangularidade (δ):       {self.geometry.delta:.2f}")
        print(f"  Volume do Plasma:          {self.geometry.volume:.1f} m³")
        print(f"  Razão de Aspecto:          {self.geometry.aspect_ratio:.2f}")
        
        print(f"\nCAMPOS MAGNÉTICOS:")
        print(f"  Campo Toroidal (B_T):      {self.magnetic.B_T:.2f} T")
        print(f"  Corrente de Plasma (I_p):  {self.magnetic.I_p:.2f} MA")
        print(f"  Fator de Segurança (q95):  {self.q95:.2f}")
        
        print(f"\nESTADO INICIAL:")
        print(f"  Temperatura Eletrônica:    {self.state.T_e:.2f} keV")
        print(f"  Temperatura Iônica:        {self.state.T_i:.2f} keV")
        print(f"  Densidade Eletrônica:      {self.state.n_e:.2e} m⁻³")
        print(f"  Densidade Iônica:          {self.state.n_i:.2e} m⁻³")
        print(f"  Posição Vertical (Z):      {self.state.Z:.3f} m")
        
        print(f"\nLIMITES OPERACIONAIS:")
        print(f"  Limite de Greenwald:       {self.n_greenwald:.2e} m⁻³")
        print(f"  Fração de Greenwald:       {self.state.n_e/self.n_greenwald*100:.1f}%")
        print(f"  Beta Poloidal:             {self.beta_poloidal:.3f}")
        print("=" * 70)

# ==========================================
# CONFIGURAÇÕES PRÉ-DEFINIDAS
# ==========================================

def create_iter_like_config():
    """Cria configuração tipo ITER"""
    geometry = TokamakGeometry(
        R0=6.2,
        a=2.0,
        kappa=1.7,
        delta=0.33
    )
    
    magnetic = MagneticConfiguration(
        B_T=5.3,
        I_p=15.0
    )
    
    initial_state = PlasmaState(
        T_e=10.0,
        T_i=10.0,
        n_e=1.0e20,
        n_i=1.0e20,
        Z=0.0,
        Z_dot=0.0,
        l_i=0.8,
        P_rad=0.0,
        Z_eff=1.5
    )
    
    return TokamakConfiguration(geometry, magnetic, initial_state)

def create_compact_config():
    """Cria configuração de tokamak compacto (tipo SPARC)"""
    geometry = TokamakGeometry(
        R0=1.85,
        a=0.57,
        kappa=1.97,
        delta=0.40
    )
    
    magnetic = MagneticConfiguration(
        B_T=12.2,
        I_p=8.7
    )
    
    initial_state = PlasmaState(
        T_e=8.0,
        T_i=8.0,
        n_e=1.5e20,
        n_i=1.5e20,
        Z=0.0,
        Z_dot=0.0,
        l_i=0.85,
        P_rad=0.0,
        Z_eff=1.8
    )
    
    return TokamakConfiguration(geometry, magnetic, initial_state)

# ==========================================
# TESTE
# ==========================================

if __name__ == "__main__":
    # Teste configuração ITER-like
    config = create_iter_like_config()
    config.print_summary()
    
    print("\n")
    
    # Teste configuração compacta
    config_compact = create_compact_config()
    config_compact.print_summary()
