"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Dinâmica de Plasma: Equações MHD e Transporte

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import numpy as np
from src.constants import *
from src.tokamak_config import *

# ==========================================
# PERFIS RADIAIS
# ==========================================

class PlasmaProfiles:
    """
    Perfis radiais de temperatura e densidade
    Modelo: Perfis parabólicos (simplificado)
    """
    
    @staticmethod
    def temperature_profile(r, T0, alpha=2.0):
        """
        Perfil de temperatura parabólico
        
        T(r) = T0 * (1 - (r/a)^α)
        
        Args:
            r: Raio normalizado [0, 1]
            T0: Temperatura central [keV]
            alpha: Expoente do perfil (tipicamente 2-3)
        
        Returns:
            Temperatura em keV
        """
        return T0 * (1.0 - r**alpha)
    
    @staticmethod
    def density_profile(r, n0, alpha=1.5):
        """
        Perfil de densidade parabólico
        
        n(r) = n0 * (1 - (r/a)^α)
        
        Args:
            r: Raio normalizado [0, 1]
            n0: Densidade central [m^-3]
            alpha: Expoente do perfil
        
        Returns:
            Densidade em m^-3
        """
        return n0 * (1.0 - r**alpha)
    
    @staticmethod
    def volume_average(profile_func, *args):
        """
        Calcula média volumétrica de um perfil
        
        <f> = ∫ f(r) dV / V
        
        Args:
            profile_func: Função do perfil
            *args: Argumentos da função
        
        Returns:
            Valor médio volumétrico
        """
        # Integração numérica simples (trapézios)
        r_grid = np.linspace(0, 1, 100)
        profile_values = profile_func(r_grid, *args)
        
        # Peso volumétrico: dV ∝ r dr
        weights = r_grid
        
        return np.trapz(profile_values * weights, r_grid) / np.trapz(weights, r_grid)

# ==========================================
# POTÊNCIA DE FUSÃO
# ==========================================

class FusionPower:
    """
    Cálculo de potência de fusão D-T
    """
    
    @staticmethod
    def fusion_power_density(n_D, n_T, T_i):
        """
        Densidade de potência de fusão [W/m^3]
        
        P_fus = n_D * n_T * <σv> * E_fusion
        
        Args:
            n_D: Densidade de deutério [m^-3]
            n_T: Densidade de trítio [m^-3]
            T_i: Temperatura iônica [keV]
        
        Returns:
            Densidade de potência em W/m^3
        """
        sigma_v = fusion_cross_section_DT(T_i)
        return n_D * n_T * sigma_v * FUSION_ENERGY_DT
    
    @staticmethod
    def alpha_power_density(n_D, n_T, T_i):
        """
        Densidade de potência de partículas alfa [W/m^3]
        
        P_alpha = n_D * n_T * <σv> * E_alpha
        
        Args:
            n_D: Densidade de deutério [m^-3]
            n_T: Densidade de trítio [m^-3]
            T_i: Temperatura iônica [keV]
        
        Returns:
            Densidade de potência em W/m^3
        """
        sigma_v = fusion_cross_section_DT(T_i)
        return n_D * n_T * sigma_v * ALPHA_ENERGY
    
    @staticmethod
    def total_fusion_power(state: PlasmaState, geometry: TokamakGeometry):
        """
        Potência total de fusão [MW]
        
        Args:
            state: Estado do plasma
            geometry: Geometria do tokamak
        
        Returns:
            Potência total em MW
        """
        # Assume mistura 50/50 D-T
        n_D = state.n_i / 2.0
        n_T = state.n_i / 2.0
        
        # Potência volumétrica média
        P_fus_density = FusionPower.fusion_power_density(n_D, n_T, state.T_i)
        
        # Potência total
        P_fus_total = P_fus_density * geometry.volume
        
        return P_fus_total / 1e6  # Converte para MW

# ==========================================
# PERDAS DE POTÊNCIA
# ==========================================

class PowerLosses:
    """
    Cálculo de perdas de potência
    """
    
    @staticmethod
    def bremsstrahlung_power(state: PlasmaState, geometry: TokamakGeometry):
        """
        Potência de radiação de Bremsstrahlung [MW]
        
        P_brem = C_brem * n_e² * sqrt(T_e) * V
        
        Args:
            state: Estado do plasma
            geometry: Geometria do tokamak
        
        Returns:
            Potência em MW
        """
        C_brem = bremsstrahlung_coefficient(state.Z_eff)
        
        # Densidade de potência [W/m^3]
        P_brem_density = C_brem * state.n_e**2 * np.sqrt(keV_to_K(state.T_e))
        
        # Potência total
        P_brem_total = P_brem_density * geometry.volume
        
        return P_brem_total / 1e6  # Converte para MW
    
    @staticmethod
    def transport_power_loss(state: PlasmaState, geometry: TokamakGeometry, B_T: float):
        """
        Perdas por transporte anômalo (modelo Bohm) [MW]
        
        P_trans = (3/2) * n * T * V / τ_E
        
        onde τ_E é calculado via difusividade de Bohm
        
        Args:
            state: Estado do plasma
            geometry: Geometria do tokamak
            B_T: Campo toroidal [T]
        
        Returns:
            Potência em MW
        """
        # Difusividade de Bohm [m^2/s]
        chi_bohm = bohm_diffusivity(state.T_e, B_T)
        
        # Tempo de confinamento [s]
        # τ_E ≈ a² / χ
        tau_E = geometry.a**2 / chi_bohm
        
        # Energia térmica total [J]
        W_thermal = (3.0/2.0) * (
            state.n_e * eV_to_J(state.T_e * 1e3) +
            state.n_i * eV_to_J(state.T_i * 1e3)
        ) * geometry.volume
        
        # Potência de perda [W]
        P_loss = W_thermal / tau_E
        
        return P_loss / 1e6  # Converte para MW
    
    @staticmethod
    def confinement_time_ITER89P(config: TokamakConfiguration, P_heat_MW: float):
        """
        Tempo de confinamento via scaling ITER89-P
        
        τ_E = 0.048 * I_p^0.85 * R^1.2 * a^0.3 * κ^0.5 * n^0.1 * B^0.2 * A^0.5 / P^0.5
        
        Args:
            config: Configuração do tokamak
            P_heat_MW: Potência de aquecimento [MW]
        
        Returns:
            Tempo de confinamento em segundos
        """
        I_p = config.magnetic.I_p  # [MA]
        R = config.geometry.R0  # [m]
        a = config.geometry.a  # [m]
        kappa = config.geometry.kappa
        n = config.state.n_e / 1e19  # [10^19 m^-3]
        B = config.magnetic.B_T  # [T]
        A = 2.5  # Massa atômica média (D-T)
        P = P_heat_MW  # [MW]
        
        tau_E = 0.048 * (I_p**0.85) * (R**1.2) * (a**0.3) * (kappa**0.5) * \
                (n**0.1) * (B**0.2) * (A**0.5) / (P**0.5)
        
        return tau_E

# ==========================================
# PARÂMETROS ADIMENSIONAIS
# ==========================================

class DimensionlessParameters:
    """
    Cálculo de parâmetros adimensionais importantes
    """
    
    @staticmethod
    def safety_factor_q95(geometry: TokamakGeometry, magnetic: MagneticConfiguration):
        """
        Fator de segurança na borda (q95)
        
        q95 ≈ (5 a² B_T) / (R0 I_p μ0)
        
        Args:
            geometry: Geometria do tokamak
            magnetic: Configuração magnética
        
        Returns:
            q95 adimensional
        """
        numerator = 5.0 * geometry.a**2 * magnetic.B_T
        denominator = geometry.R0 * MA_to_A(magnetic.I_p) * MU_0
        
        return numerator / denominator
    
    @staticmethod
    def normalized_beta(state: PlasmaState, geometry: TokamakGeometry, 
                       magnetic: MagneticConfiguration):
        """
        Beta normalizado (β_N)
        
        β_N = β * (a * B_T) / (I_p * μ0)
        
        onde β = 2μ0 <p> / B_T²
        
        Args:
            state: Estado do plasma
            geometry: Geometria do tokamak
            magnetic: Configuração magnética
        
        Returns:
            β_N adimensional (tipicamente < 3.5)
        """
        # Pressão cinética [Pa]
        p_kin = (state.n_e * eV_to_J(state.T_e * 1e3) +
                 state.n_i * eV_to_J(state.T_i * 1e3))
        
        # Beta
        beta = (2.0 * MU_0 * p_kin) / (magnetic.B_T**2)
        
        # Beta normalizado
        beta_N = beta * (geometry.a * magnetic.B_T) / (MA_to_A(magnetic.I_p) * MU_0)
        
        return beta_N * 100.0  # Convenção: β_N em %
    
    @staticmethod
    def greenwald_fraction(state: PlasmaState, geometry: TokamakGeometry,
                          magnetic: MagneticConfiguration):
        """
        Fração do limite de Greenwald
        
        f_GW = n_e / n_GW
        
        onde n_GW = I_p / (π a²) [10^20 m^-3]
        
        Args:
            state: Estado do plasma
            geometry: Geometria do tokamak
            magnetic: Configuração magnética
        
        Returns:
            Fração de Greenwald (tipicamente < 0.85)
        """
        # Limite de Greenwald [m^-3]
        n_GW = (MA_to_A(magnetic.I_p) / (np.pi * geometry.a**2)) * 1e20
        
        return state.n_e / n_GW

# ==========================================
# INSTABILIDADES MHD
# ==========================================

class MHDInstabilities:
    """
    Detecção de instabilidades MHD
    """
    
    @staticmethod
    def tearing_mode_risk(q95: float, beta_N: float):
        """
        Risco de tearing mode (m/n = 2/1)
        
        Critério: q95 < 2.0 aumenta risco
        
        Args:
            q95: Fator de segurança
            beta_N: Beta normalizado
        
        Returns:
            Risco (0-1), 0 = seguro, 1 = alto risco
        """
        if q95 >= 2.5:
            return 0.0
        elif q95 <= 1.8:
            return 1.0
        else:
            # Interpolação linear
            return (2.5 - q95) / 0.7
    
    @staticmethod
    def ballooning_mode_risk(beta_N: float, q95: float):
        """
        Risco de ballooning mode
        
        Critério: β_N > β_crit = 2.5 / q95
        
        Args:
            beta_N: Beta normalizado
            q95: Fator de segurança
        
        Returns:
            Risco (0-1)
        """
        beta_crit = 2.5 / q95
        
        if beta_N <= 0.8 * beta_crit:
            return 0.0
        elif beta_N >= beta_crit:
            return 1.0
        else:
            return (beta_N - 0.8 * beta_crit) / (0.2 * beta_crit)
    
    @staticmethod
    def vertical_displacement_event_risk(Z: float, a: float):
        """
        Risco de VDE (Vertical Displacement Event)
        
        Critério: |Z| > 0.1 * a
        
        Args:
            Z: Posição vertical [m]
            a: Raio menor [m]
        
        Returns:
            Risco (0-1)
        """
        threshold = 0.1 * a
        
        if abs(Z) <= 0.5 * threshold:
            return 0.0
        elif abs(Z) >= threshold:
            return 1.0
        else:
            return (abs(Z) - 0.5 * threshold) / (0.5 * threshold)
    
    @staticmethod
    def disruption_risk(config: TokamakConfiguration):
        """
        Risco total de disrupção
        
        Combina todos os riscos de instabilidades
        
        Args:
            config: Configuração do tokamak
        
        Returns:
            Risco total (0-1)
        """
        q95 = DimensionlessParameters.safety_factor_q95(
            config.geometry, config.magnetic
        )
        beta_N = DimensionlessParameters.normalized_beta(
            config.state, config.geometry, config.magnetic
        )
        
        risk_tearing = MHDInstabilities.tearing_mode_risk(q95, beta_N)
        risk_ballooning = MHDInstabilities.ballooning_mode_risk(beta_N, q95)
        risk_vde = MHDInstabilities.vertical_displacement_event_risk(
            config.state.Z, config.geometry.a
        )
        
        # Risco combinado (máximo)
        return max(risk_tearing, risk_ballooning, risk_vde)

# ==========================================
# EQUAÇÕES DE EVOLUÇÃO
# ==========================================

class PlasmaEvolution:
    """
    Equações diferenciais da evolução do plasma
    """
    
    @staticmethod
    def dTe_dt(state: PlasmaState, geometry: TokamakGeometry, 
               magnetic: MagneticConfiguration, P_heat_MW: float):
        """
        Taxa de variação da temperatura eletrônica [keV/s]
        
        dT_e/dt = (P_heat - P_loss) / (3/2 * n_e * k_B * V)
        
        Args:
            state: Estado do plasma
            geometry: Geometria do tokamak
            magnetic: Configuração magnética
            P_heat_MW: Potência de aquecimento [MW]
        
        Returns:
            dT_e/dt em keV/s
        """
        # Potência de aquecimento [W]
        P_heat = MW_to_W(P_heat_MW)
        
        # Potência de fusão (auto-aquecimento) [W]
        P_alpha = FusionPower.total_fusion_power(state, geometry) * 0.2  # 20% para elétrons
        P_alpha_W = MW_to_W(P_alpha)
        
        # Perdas [W]
        P_brem = MW_to_W(PowerLosses.bremsstrahlung_power(state, geometry))
        P_trans = MW_to_W(PowerLosses.transport_power_loss(state, geometry, magnetic.B_T))
        
        # Balanço de potência
        P_net = P_heat + P_alpha_W - P_brem - P_trans
        
        # Capacidade térmica [J/keV]
        C_thermal = (3.0/2.0) * state.n_e * BOLTZMANN_CONSTANT * geometry.volume / 1e3
        
        return P_net / C_thermal
    
    @staticmethod
    def dTi_dt(state: PlasmaState, geometry: TokamakGeometry, P_heat_MW: float):
        """
        Taxa de variação da temperatura iônica [keV/s]
        
        Similar a dTe_dt, mas com aquecimento iônico
        
        Args:
            state: Estado do plasma
            geometry: Geometria do tokamak
            P_heat_MW: Potência de aquecimento iônico [MW]
        
        Returns:
            dT_i/dt em keV/s
        """
        # Simplificado: assume acoplamento colisional com elétrons
        # dT_i/dt ≈ (T_e - T_i) / τ_eq + P_heat_ion / C_thermal
        
        tau_eq = 0.1  # Tempo de equilibração [s]
        
        P_heat = MW_to_W(P_heat_MW)
        C_thermal = (3.0/2.0) * state.n_i * BOLTZMANN_CONSTANT * geometry.volume / 1e3
        
        return (state.T_e - state.T_i) / tau_eq + P_heat / C_thermal
    
    @staticmethod
    def dZ_dt(state: PlasmaState):
        """
        Taxa de variação da posição vertical [m/s]
        
        dZ/dt = Z_dot
        
        Args:
            state: Estado do plasma
        
        Returns:
            dZ/dt em m/s
        """
        return state.Z_dot
    
    @staticmethod
    def dZ_dot_dt(state: PlasmaState, geometry: TokamakGeometry, 
                   magnetic: MagneticConfiguration, F_z_MN: float):
        """
        Taxa de variação da velocidade vertical [m/s²]
        
        Equação de movimento vertical (simplificada):
        M * dZ_dot/dt = F_z - k_z * Z
        
        Args:
            state: Estado do plasma
            geometry: Geometria do tokamak
            magnetic: Configuração magnética
            F_z_MN: Força vertical de controle [MN]
        
        Returns:
            dZ_dot/dt em m/s²
        """
        # Massa efetiva do plasma [kg]
        M_eff = state.n_i * (DEUTERIUM_MASS + TRITIUM_MASS) / 2.0 * geometry.volume
        
        # Constante de restauração vertical [N/m]
        k_z = 1e7  # Valor típico
        
        # Força total [N]
        F_total = F_z_MN * 1e6 - k_z * state.Z
        
        return F_total / M_eff

# ==========================================
# TESTE
# ==========================================

if __name__ == "__main__":
    # Criar configuração de teste
    config = create_iter_like_config()
    
    print("=" * 70)
    print("TESTE DE DINÂMICA DE PLASMA")
    print("=" * 70)
    
    # Teste 1: Potência de fusão
    P_fus = FusionPower.total_fusion_power(config.state, config.geometry)
    print(f"\nPotência de Fusão: {P_fus:.2f} MW")
    
    # Teste 2: Perdas
    P_brem = PowerLosses.bremsstrahlung_power(config.state, config.geometry)
    P_trans = PowerLosses.transport_power_loss(config.state, config.geometry, config.magnetic.B_T)
    print(f"Perda por Bremsstrahlung: {P_brem:.2f} MW")
    print(f"Perda por Transporte: {P_trans:.2f} MW")
    
    # Teste 3: Parâmetros adimensionais
    q95 = DimensionlessParameters.safety_factor_q95(config.geometry, config.magnetic)
    beta_N = DimensionlessParameters.normalized_beta(config.state, config.geometry, config.magnetic)
    f_GW = DimensionlessParameters.greenwald_fraction(config.state, config.geometry, config.magnetic)
    
    print(f"\nFator de Segurança (q95): {q95:.2f}")
    print(f"Beta Normalizado (β_N): {beta_N:.2f}")
    print(f"Fração de Greenwald: {f_GW:.2%}")
    
    # Teste 4: Risco de disrupção
    risk = MHDInstabilities.disruption_risk(config)
    print(f"\nRisco de Disrupção: {risk:.2%}")
    
    print("=" * 70)
