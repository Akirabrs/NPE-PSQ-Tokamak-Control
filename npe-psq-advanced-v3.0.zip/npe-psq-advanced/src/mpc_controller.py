"""
NPE-PSQ Advanced Tokamak Simulator v3.0
========================================
Controlador Model Predictive Control (MPC)

Autor: Guilherme Brasil de Souza
Data: Dezembro 2025
"""

import numpy as np
import cvxpy as cp
from dataclasses import dataclass
from typing import Dict, Optional
from src.tokamak_config import *
from src.plasma_dynamics import *

# ==========================================
# CONFIGURAÇÃO DO MPC
# ==========================================

@dataclass
class MPCConfig:
    """
    Parâmetros de configuração do MPC
    """
    # Horizonte de predição
    N: int = 20
    
    # Setpoints de referência
    T_e_ref: float = 10.0  # [keV]
    T_i_ref: float = 10.0  # [keV]
    Z_ref: float = 0.0     # [m]
    
    # Pesos da função custo (Q matrix)
    w_T_e: float = 100.0
    w_T_i: float = 100.0
    w_Z: float = 1000.0
    w_Z_dot: float = 100.0
    
    # Pesos de controle (R matrix)
    w_P_NBI: float = 0.1
    w_P_ECRH: float = 0.1
    w_P_ICRH: float = 0.1
    w_F_z: float = 1.0
    
    # Limites de atuadores
    P_NBI_max: float = 33.0   # [MW]
    P_ECRH_max: float = 20.0  # [MW]
    P_ICRH_max: float = 20.0  # [MW]
    F_z_max: float = 5.0      # [MN]
    
    # Passo de tempo
    dt: float = 0.1  # [s]

# ==========================================
# CONTROLADOR MPC
# ==========================================

class MPCController:
    """
    Controlador Model Predictive Control para tokamak
    
    Minimiza:
        J = Σ ||x_k - x_ref||²_Q + ||u_k||²_R
    
    Sujeito a:
        x_{k+1} = A x_k + B u_k  (dinâmica linearizada)
        u_min ≤ u_k ≤ u_max
    """
    
    def __init__(self,
                 geometry: TokamakGeometry,
                 magnetic: MagneticConfiguration,
                 config: MPCConfig):
        self.geometry = geometry
        self.magnetic = magnetic
        self.config = config
        
        # Matrizes de linearização (calculadas em tempo de execução)
        self.A = None
        self.B = None
        
        # Problema de otimização (construído uma vez)
        self._build_optimization_problem()
    
    def _build_optimization_problem(self):
        """
        Constrói o problema de otimização CVXPY
        """
        N = self.config.N
        
        # Dimensões
        n_states = 4  # [T_e, T_i, Z, Z_dot]
        n_controls = 4  # [P_NBI, P_ECRH, P_ICRH, F_z]
        
        # Variáveis de decisão
        self.x_var = cp.Variable((n_states, N+1))  # Estados
        self.u_var = cp.Variable((n_controls, N))  # Controles
        
        # Parâmetros
        self.x0_param = cp.Parameter(n_states)  # Estado inicial
        self.x_ref_param = cp.Parameter(n_states)  # Referência
        self.A_param = cp.Parameter((n_states, n_states))  # Matriz A
        self.B_param = cp.Parameter((n_states, n_controls))  # Matriz B
        
        # Matrizes de peso
        Q = np.diag([
            self.config.w_T_e,
            self.config.w_T_i,
            self.config.w_Z,
            self.config.w_Z_dot
        ])
        
        R = np.diag([
            self.config.w_P_NBI,
            self.config.w_P_ECRH,
            self.config.w_P_ICRH,
            self.config.w_F_z
        ])
        
        # Função custo
        cost = 0
        constraints = []
        
        # Condição inicial
        constraints.append(self.x_var[:, 0] == self.x0_param)
        
        # Loop sobre horizonte
        for k in range(N):
            # Custo de tracking
            error = self.x_var[:, k] - self.x_ref_param
            cost += cp.quad_form(error, Q)
            
            # Custo de controle
            cost += cp.quad_form(self.u_var[:, k], R)
            
            # Dinâmica
            constraints.append(
                self.x_var[:, k+1] == self.A_param @ self.x_var[:, k] + 
                                      self.B_param @ self.u_var[:, k]
            )
            
            # Limites de controle
            constraints.append(self.u_var[0, k] >= 0)  # P_NBI
            constraints.append(self.u_var[0, k] <= self.config.P_NBI_max)
            
            constraints.append(self.u_var[1, k] >= 0)  # P_ECRH
            constraints.append(self.u_var[1, k] <= self.config.P_ECRH_max)
            
            constraints.append(self.u_var[2, k] >= 0)  # P_ICRH
            constraints.append(self.u_var[2, k] <= self.config.P_ICRH_max)
            
            constraints.append(self.u_var[3, k] >= -self.config.F_z_max)  # F_z
            constraints.append(self.u_var[3, k] <= self.config.F_z_max)
        
        # Custo terminal
        error_final = self.x_var[:, N] - self.x_ref_param
        cost += cp.quad_form(error_final, Q)
        
        # Problema de otimização
        self.problem = cp.Problem(cp.Minimize(cost), constraints)
    
    def _linearize_dynamics(self, state: PlasmaState) -> tuple:
        """
        Lineariza a dinâmica em torno do estado atual
        
        x_{k+1} ≈ A x_k + B u_k
        
        Args:
            state: Estado atual do plasma
        
        Returns:
            (A, B) matrizes de linearização
        """
        dt = self.config.dt
        
        # Matriz A (identidade + derivadas parciais)
        # Simplificação: assume dinâmica desacoplada
        A = np.eye(4)
        
        # Temperatura eletrônica decai naturalmente
        tau_E = 0.1  # Tempo de confinamento típico [s]
        A[0, 0] = 1.0 - dt / tau_E
        
        # Temperatura iônica acopla com eletrônica
        A[1, 1] = 1.0 - dt / tau_E
        A[1, 0] = dt / tau_E * 0.5  # Acoplamento
        
        # Posição vertical
        A[2, 3] = dt  # Z += Z_dot * dt
        
        # Velocidade vertical (restauração)
        k_z = 1e7  # [N/m]
        M_eff = state.n_i * DEUTERIUM_MASS * self.geometry.volume
        A[3, 2] = -dt * k_z / M_eff
        A[3, 3] = 1.0 - dt * 0.1  # Amortecimento
        
        # Matriz B (efeito dos controles)
        B = np.zeros((4, 4))
        
        # Aquecimento afeta temperaturas
        C_thermal_e = (3.0/2.0) * state.n_e * BOLTZMANN_CONSTANT * self.geometry.volume / 1e3
        C_thermal_i = (3.0/2.0) * state.n_i * BOLTZMANN_CONSTANT * self.geometry.volume / 1e3
        
        # P_NBI aquece ambos (50/50)
        B[0, 0] = dt * 0.5 * MW_to_W(1.0) / C_thermal_e
        B[1, 0] = dt * 0.5 * MW_to_W(1.0) / C_thermal_i
        
        # P_ECRH aquece elétrons
        B[0, 1] = dt * MW_to_W(1.0) / C_thermal_e
        
        # P_ICRH aquece íons
        B[1, 2] = dt * MW_to_W(1.0) / C_thermal_i
        
        # F_z afeta velocidade vertical
        B[3, 3] = dt * 1e6 / M_eff  # MN para N
        
        return A, B
    
    def compute_control(self, state: PlasmaState) -> ControlActuators:
        """
        Calcula controle ótimo via MPC
        
        Args:
            state: Estado atual do plasma
        
        Returns:
            Atuadores de controle otimizados
        """
        # Lineariza dinâmica
        A, B = self._linearize_dynamics(state)
        
        # Estado atual (reduzido)
        x0 = np.array([state.T_e, state.T_i, state.Z, state.Z_dot])
        
        # Referência
        x_ref = np.array([
            self.config.T_e_ref,
            self.config.T_i_ref,
            self.config.Z_ref,
            0.0  # Z_dot_ref = 0
        ])
        
        # Atualiza parâmetros
        self.x0_param.value = x0
        self.x_ref_param.value = x_ref
        self.A_param.value = A
        self.B_param.value = B
        
        # Resolve problema
        try:
            self.problem.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            
            if self.problem.status == cp.OPTIMAL:
                # Extrai primeiro controle (receding horizon)
                u_opt = self.u_var[:, 0].value
                
                return ControlActuators(
                    P_NBI=float(u_opt[0]),
                    P_ECRH=float(u_opt[1]),
                    P_ICRH=float(u_opt[2]),
                    F_z=float(u_opt[3])
                )
            else:
                print(f"[MPC] Otimização falhou: {self.problem.status}")
                return self._fallback_control(state)
        
        except Exception as e:
            print(f"[MPC] Erro: {e}")
            return self._fallback_control(state)
    
    def _fallback_control(self, state: PlasmaState) -> ControlActuators:
        """
        Controle de fallback (PID simples)
        
        Args:
            state: Estado atual
        
        Returns:
            Controle de segurança
        """
        # PID simples para temperatura
        K_p = 2.0
        error_T = self.config.T_e_ref - state.T_e
        P_heat = K_p * error_T
        P_heat = np.clip(P_heat, 0, 50.0)
        
        # PID para posição vertical
        K_p_z = 100.0
        K_d_z = 10.0
        error_Z = self.config.Z_ref - state.Z
        F_z = K_p_z * error_Z - K_d_z * state.Z_dot
        F_z = np.clip(F_z, -self.config.F_z_max, self.config.F_z_max)
        
        return ControlActuators(
            P_NBI=P_heat * 0.5,
            P_ECRH=P_heat * 0.3,
            P_ICRH=P_heat * 0.2,
            F_z=F_z
        )

# ==========================================
# TESTE
# ==========================================

if __name__ == "__main__":
    print("=" * 70)
    print("TESTE DO CONTROLADOR MPC")
    print("=" * 70)
    
    # Criar configuração
    config = create_iter_like_config()
    
    # Configuração do MPC
    mpc_config = MPCConfig(
        N=15,
        T_e_ref=12.0,
        T_i_ref=12.0,
        Z_ref=0.0
    )
    
    # Criar controlador
    controller = MPCController(
        config.geometry,
        config.magnetic,
        mpc_config
    )
    
    # Estado de teste (abaixo da referência)
    test_state = PlasmaState(
        T_e=8.0,
        T_i=8.0,
        n_e=1.0e20,
        n_i=1.0e20,
        Z=0.05,
        Z_dot=0.1
    )
    
    print("\nEstado Atual:")
    print(f"  T_e = {test_state.T_e:.2f} keV (ref: {mpc_config.T_e_ref:.2f})")
    print(f"  T_i = {test_state.T_i:.2f} keV (ref: {mpc_config.T_i_ref:.2f})")
    print(f"  Z = {test_state.Z:.3f} m (ref: {mpc_config.Z_ref:.3f})")
    
    # Calcula controle
    print("\nCalculando controle MPC...")
    actuators = controller.compute_control(test_state)
    
    print("\nControle Otimizado:")
    print(f"  P_NBI = {actuators.P_NBI:.2f} MW")
    print(f"  P_ECRH = {actuators.P_ECRH:.2f} MW")
    print(f"  P_ICRH = {actuators.P_ICRH:.2f} MW")
    print(f"  F_z = {actuators.F_z:.2f} MN")
    print(f"  P_total = {actuators.total_heating_power():.2f} MW")
    
    print("=" * 70)
