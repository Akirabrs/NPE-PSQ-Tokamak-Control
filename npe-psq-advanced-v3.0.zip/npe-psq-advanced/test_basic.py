"""Teste básico do simulador sem dependências externas"""
import sys
sys.path.append('/home/ubuntu/npe-psq-advanced')

print("=" * 70)
print("TESTE BÁSICO DO SIMULADOR NPE-PSQ v3.0")
print("=" * 70)

# Teste 1: Constantes
print("\n[1/5] Testando constantes físicas...")
from src.constants import *
print(f"  ✓ ELEMENTARY_CHARGE = {ELEMENTARY_CHARGE:.3e} C")
print(f"  ✓ ELECTRON_MASS = {ELECTRON_MASS:.3e} kg")
print(f"  ✓ BOLTZMANN_CONSTANT = {BOLTZMANN_CONSTANT:.3e} J/K")

# Teste 2: Configuração
print("\n[2/5] Testando configuração do tokamak...")
from src.tokamak_config import create_iter_like_config
config = create_iter_like_config()
print(f"  ✓ R0 = {config.geometry.R0:.2f} m")
print(f"  ✓ B_T = {config.magnetic.B_T:.2f} T")
print(f"  ✓ I_p = {config.magnetic.I_p:.2f} MA")
print(f"  ✓ Volume = {config.geometry.volume:.1f} m³")

# Teste 3: Dinâmica
print("\n[3/5] Testando dinâmica de plasma...")
from src.plasma_dynamics import FusionPower, DimensionlessParameters
P_fus = FusionPower.total_fusion_power(config.state, config.geometry)
q95 = DimensionlessParameters.safety_factor_q95(config.geometry, config.magnetic)
print(f"  ✓ P_fusão = {P_fus:.2f} MW")
print(f"  ✓ q95 = {q95:.2f}")

# Teste 4: Integração
print("\n[4/5] Testando integração numérica...")
from src.numerical_integration import RK4Integrator
integrator = RK4Integrator()
print(f"  ✓ dt_initial = {integrator.dt:.4f} s")
print(f"  ✓ tolerance = {integrator.tolerance:.1e}")

# Teste 5: Sistema de segurança
print("\n[5/5] Testando sistema de segurança PSQ...")
from src.safety_system import PlasmaStabilityQuenching
psq = PlasmaStabilityQuenching()
is_safe, code, msg = psq.check_safety(config.state, config.geometry, config.magnetic)
print(f"  ✓ Estado: {'SEGURO' if is_safe else 'VIOLAÇÃO'}")
print(f"  ✓ Código: {code.name}")

print("\n" + "=" * 70)
print("✓ TODOS OS TESTES BÁSICOS PASSARAM!")
print("=" * 70)
