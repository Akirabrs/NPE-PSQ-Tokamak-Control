"""
Operadores Diferenciais e Métricas 2D para o Simulador NPE-PSQ

Este módulo implementa o cálculo dos tensores métricos e dos operadores
diferenciais (Grad, Div, Lap) em coordenadas toroidais (ρ, θ).
"""

import numpy as np
from typing import Tuple, Dict
import sys
sys.path.append('..')

from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D


class DifferentialOperators2D:
    """
    Implementa operadores diferenciais em coordenadas (ρ, θ).
    """
    
    def __init__(self, geometry: TokamakGeometry2D, grid: Grid2D):
        """
        Inicializa os operadores.
        
        Args:
            geometry: Geometria do tokamak
            grid: Grade computacional 2D
        """
        self.geometry = geometry
        self.grid = grid
        
        # Pré-calcular métricas
        self._compute_metrics()
    
    def _compute_metrics(self):
        """
        Calcula os componentes do tensor métrico g_ij e o Jacobiano.
        
        Em coordenadas (ρ, θ):
        g_ρρ = (∂R/∂ρ)² + (∂Z/∂ρ)²
        g_θθ = (∂R/∂θ)² + (∂Z/∂θ)²
        g_ρθ = (∂R/∂ρ)(∂R/∂θ) + (∂Z/∂ρ)(∂Z/∂θ)
        
        Jacobiano J = sqrt(g_ρρ g_θθ - g_ρθ²)
        """
        rho = self.grid.rho_2d
        theta = self.grid.theta_2d
        
        # Parâmetros
        a = self.geometry.a
        kappa = self.geometry.kappa
        delta = self.geometry.delta
        
        # Ângulo modificado pela triangularidade
        theta_mod = theta + delta * np.sin(theta)
        dtheta_mod_dtheta = 1 + delta * np.cos(theta)
        
        # Derivadas de R
        dR_drho = a * np.cos(theta_mod)
        dR_dtheta = -rho * a * np.sin(theta_mod) * dtheta_mod_dtheta
        
        # Derivadas de Z
        dZ_drho = a * kappa * np.sin(theta)
        dZ_dtheta = rho * a * kappa * np.cos(theta)
        
        # Componentes do tensor métrico (covariante)
        self.g_rho_rho = dR_drho**2 + dZ_drho**2
        self.g_theta_theta = dR_dtheta**2 + dZ_dtheta**2
        self.g_rho_theta = dR_drho * dR_dtheta + dZ_drho * dZ_dtheta
        
        # Jacobiano (determinante da métrica)
        # J = sqrt(det(g)) = sqrt(g_ρρ g_θθ - g_ρθ²)
        self.J = np.sqrt(np.maximum(self.g_rho_rho * self.g_theta_theta - self.g_rho_theta**2, 1e-10))
        
        # Componentes do tensor métrico (contravariante) g^ij = (g_ij)^-1
        det_g = self.J**2
        self.g_inv_rho_rho = self.g_theta_theta / det_g
        self.g_inv_theta_theta = self.g_rho_rho / det_g
        self.g_inv_rho_theta = -self.g_rho_theta / det_g
        
        # Raio maior R
        self.R = self.geometry.compute_R(rho, theta)
    
    def gradient(self, f: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Calcula o gradiente de um escalar f: ∇f = (∂f/∂ρ) ∇ρ + (∂f/∂θ) ∇θ.
        
        Args:
            f: Campo escalar 2D [n_rho, n_theta]
            
        Returns:
            Tupla (grad_rho, grad_theta)
        """
        df_drho = np.gradient(f, self.grid.drho, axis=0)
        df_dtheta = np.gradient(f, self.grid.dtheta, axis=1)
        
        # Componentes contravariantes do gradiente
        grad_rho = self.g_inv_rho_rho * df_drho + self.g_inv_rho_theta * df_dtheta
        grad_theta = self.g_inv_rho_theta * df_drho + self.g_inv_theta_theta * df_dtheta
        
        return grad_rho, grad_theta
    
    def divergence(self, v_rho: np.ndarray, v_theta: np.ndarray) -> np.ndarray:
        """
        Calcula a divergência de um vetor V: ∇·V = (1/RJ) [∂(R J v^ρ)/∂ρ + ∂(R J v^θ)/∂θ].
        
        Args:
            v_rho: Componente radial contravariante
            v_theta: Componente poloidal contravariante
            
        Returns:
            Divergência (escalar)
        """
        term1 = self.R * self.J * v_rho
        term2 = self.R * self.J * v_theta
        
        d_term1_drho = np.gradient(term1, self.grid.drho, axis=0)
        d_term2_dtheta = np.gradient(term2, self.grid.dtheta, axis=1)
        
        div = (1.0 / (self.R * self.J + 1e-10)) * (d_term1_drho + d_term2_dtheta)
        
        return div
    
    def laplacian(self, f: np.ndarray) -> np.ndarray:
        """
        Calcula o Laplaciano de um escalar f: ∇²f = ∇·(∇f).
        
        Args:
            f: Campo escalar 2D
            
        Returns:
            Laplaciano (escalar)
        """
        grad_rho, grad_theta = self.gradient(f)
        lap = self.divergence(grad_rho, grad_theta)
        
        return lap
    
    def laplacian_diffusion(self, f: np.ndarray, chi: np.ndarray) -> np.ndarray:
        """
        Calcula o termo de difusão: ∇·(χ ∇f).
        
        Args:
            f: Campo escalar 2D
            chi: Coeficiente de difusão (pode ser 2D)
            
        Returns:
            Termo de difusão
        """
        grad_rho, grad_theta = self.gradient(f)
        
        # Fluxo = -chi * grad
        flux_rho = chi * grad_rho
        flux_theta = chi * grad_theta
        
        diff = self.divergence(flux_rho, flux_theta)
        
        return diff


if __name__ == "__main__":
    # Teste do módulo
    print("=" * 80)
    print("TESTE DO MÓDULO DifferentialOperators2D")
    print("=" * 80)
    
    # Criar geometria e grade
    geom = TokamakGeometry2D()
    grid = Grid2D(n_rho=100, n_theta=64)
    
    # Criar operadores
    ops = DifferentialOperators2D(geom, grid)
    
    print("\nMétricas calculadas:")
    print(f"  g_ρρ (média): {ops.g_rho_rho.mean():.3f}")
    print(f"  g_θθ (média): {ops.g_theta_theta.mean():.3f}")
    print(f"  J (média):    {ops.J.mean():.3f}")
    
    # Testar gradiente de um perfil parabólico
    f = (1 - grid.rho_2d**2)
    grad_rho, grad_theta = ops.gradient(f)
    
    print("\nGradiente de f = 1 - ρ²:")
    print(f"  grad_ρ(ρ=0.5, θ=0): {grad_rho[50, 0]:.3f} (esperado: -1.0 approx)")
    print(f"  grad_θ(ρ=0.5, θ=0): {grad_theta[50, 0]:.3f} (esperado: 0.0)")
    
    # Testar Laplaciano
    lap = ops.laplacian(f)
    
    print("\nLaplaciano de f = 1 - ρ²:")
    print(f"  ∇²f (média): {lap.mean():.3f}")
    
    # Testar difusão
    chi = np.ones_like(f) * 1.0
    diff = ops.laplacian_diffusion(f, chi)
    
    print("\nDifusão ∇·(1.0 ∇f):")
    print(f"  Difusão (média): {diff.mean():.3f}")
    
    print("\n" + "=" * 80)
