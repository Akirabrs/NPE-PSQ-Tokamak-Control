"""
Geometria Toroidal 2D para o Simulador NPE-PSQ

Este módulo implementa a geometria toroidal completa com elongação
e triangularidade, incluindo o cálculo do Jacobiano e métricas.
"""

import numpy as np
from dataclasses import dataclass
from typing import Tuple


@dataclass
class TokamakGeometry2D:
    """
    Geometria do tokamak NPE-PSQ em 2D (ρ, θ).
    """
    
    # Parâmetros geométricos
    R0: float = 6.2      # Raio maior [m]
    a: float = 2.0       # Raio menor [m]
    kappa: float = 1.7   # Elongação
    delta: float = 0.33  # Triangularidade
    
    # Campo magnético
    B0: float = 5.3      # Campo toroidal no eixo [T]
    
    # Corrente de plasma
    Ip_max: float = 15.0 # Corrente máxima [MA]
    
    @property
    def epsilon(self) -> float:
        """Razão de aspecto."""
        return self.a / self.R0
    
    @property
    def volume(self) -> float:
        """Volume do plasma [m³]."""
        return 2 * np.pi**2 * self.R0 * self.a**2 * self.kappa
    
    def compute_R(self, rho: np.ndarray, theta: np.ndarray) -> np.ndarray:
        """
        Calcula o raio maior R(ρ, θ).
        
        R(ρ, θ) = R₀ + ρ a cos(θ + δ sin θ)
        
        Args:
            rho: Coordenada radial normalizada [0, 1]
            theta: Ângulo poloidal [0, 2π]
            
        Returns:
            Raio maior R [m]
        """
        # Ângulo modificado pela triangularidade
        theta_mod = theta + self.delta * np.sin(theta)
        
        R = self.R0 + rho * self.a * np.cos(theta_mod)
        
        return R
    
    def compute_Z(self, rho: np.ndarray, theta: np.ndarray) -> np.ndarray:
        """
        Calcula a altura Z(ρ, θ).
        
        Z(ρ, θ) = ρ a κ sin θ
        
        Args:
            rho: Coordenada radial normalizada [0, 1]
            theta: Ângulo poloidal [0, 2π]
            
        Returns:
            Altura Z [m]
        """
        Z = rho * self.a * self.kappa * np.sin(theta)
        
        return Z
    
    def compute_RZ(self, rho: np.ndarray, theta: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Calcula as coordenadas cartesianas (R, Z).
        
        Args:
            rho: Coordenada radial normalizada
            theta: Ângulo poloidal
            
        Returns:
            Tupla (R, Z)
        """
        R = self.compute_R(rho, theta)
        Z = self.compute_Z(rho, theta)
        
        return R, Z
    
    def compute_jacobian(self, rho: np.ndarray, theta: np.ndarray) -> np.ndarray:
        """
        Calcula o Jacobiano da transformação (ρ, θ) → (R, Z).
        
        J = |∂R/∂ρ  ∂R/∂θ|
            |∂Z/∂ρ  ∂Z/∂θ|
        
        Args:
            rho: Coordenada radial normalizada
            theta: Ângulo poloidal
            
        Returns:
            Jacobiano J
        """
        # Derivadas de R
        theta_mod = theta + self.delta * np.sin(theta)
        dtheta_mod_dtheta = 1 + self.delta * np.cos(theta)
        
        dR_drho = self.a * np.cos(theta_mod)
        dR_dtheta = -rho * self.a * np.sin(theta_mod) * dtheta_mod_dtheta
        
        # Derivadas de Z
        dZ_drho = self.a * self.kappa * np.sin(theta)
        dZ_dtheta = rho * self.a * self.kappa * np.cos(theta)
        
        # Jacobiano
        J = dR_drho * dZ_dtheta - dR_dtheta * dZ_drho
        
        return J
    
    def compute_volume_element(self, rho: np.ndarray, theta: np.ndarray) -> np.ndarray:
        """
        Calcula o elemento de volume dV = 2π R J dρ dθ.
        
        Args:
            rho: Coordenada radial normalizada
            theta: Ângulo poloidal
            
        Returns:
            Elemento de volume [m³]
        """
        R = self.compute_R(rho, theta)
        J = self.compute_jacobian(rho, theta)
        
        dV = 2 * np.pi * R * J
        
        return dV
    
    def compute_poloidal_circumference(self, rho: float, n_points: int = 1000) -> float:
        """
        Calcula o comprimento da circunferência poloidal em ρ.
        
        Args:
            rho: Coordenada radial normalizada
            n_points: Número de pontos para integração
            
        Returns:
            Comprimento poloidal [m]
        """
        theta = np.linspace(0, 2*np.pi, n_points)
        
        R = self.compute_R(rho * np.ones_like(theta), theta)
        Z = self.compute_Z(rho * np.ones_like(theta), theta)
        
        # Derivadas
        dR = np.gradient(R, theta)
        dZ = np.gradient(Z, theta)
        
        # Elemento de comprimento
        dl = np.sqrt(dR**2 + dZ**2)
        
        # Integração
        L_pol = np.trapezoid(dl, theta)
        
        return L_pol
    
    def compute_safety_factor(self, rho: np.ndarray, Ip: float) -> np.ndarray:
        """
        Calcula o fator de segurança q(ρ).
        
        Para geometria circular: q(ρ) = (2πa²B₀)/(R₀μ₀Ip) × ρ
        Para geometria alongada: correção por κ e δ
        
        Args:
            rho: Coordenada radial normalizada
            Ip: Corrente de plasma [MA]
            
        Returns:
            Fator de segurança q(ρ)
        """
        if Ip == 0:
            return np.ones_like(rho) * 1e6
        
        # Conversão: Ip em MA → A
        Ip_A = Ip * 1e6
        
        mu_0 = 4 * np.pi * 1e-7
        
        # Fator de forma para geometria alongada
        # Aproximação: q_cyl × (1 + κ²) / 2
        form_factor = (1 + self.kappa**2) / 2
        
        # q cilíndrico
        q_cyl = (2 * np.pi * self.a**2 * self.B0) / (self.R0 * mu_0 * Ip_A)
        
        # Perfil parabólico de corrente: q(ρ) = q₀(1 + ρ²)
        q_0 = q_cyl * form_factor
        q_profile = q_0 * (1 + rho**2)
        
        # Evitar valores muito pequenos no centro
        q_profile = np.maximum(q_profile, 0.5)
        
        return q_profile
    
    def compute_magnetic_shear(self, rho: np.ndarray, Ip: float) -> np.ndarray:
        """
        Calcula o shear magnético s = (ρ/q) dq/dρ.
        
        Args:
            rho: Coordenada radial normalizada
            Ip: Corrente de plasma [MA]
            
        Returns:
            Shear magnético s(ρ)
        """
        q = self.compute_safety_factor(rho, Ip)
        
        # Derivada numérica
        drho = rho[1] - rho[0] if len(rho) > 1 else 0.01
        dq_drho = np.gradient(q, drho)
        
        # Shear
        s = (rho / (q + 1e-10)) * dq_drho
        
        return s


class Grid2D:
    """
    Grade computacional 2D estruturada.
    """
    
    def __init__(self, 
                 n_rho: int = 100, 
                 n_theta: int = 64,
                 rho_min: float = 0.0,
                 rho_max: float = 1.0,
                 packing_factor: float = 1.0):
        """
        Inicializa a grade 2D.
        
        Args:
            n_rho: Número de pontos radiais
            n_theta: Número de pontos poloidais
            rho_min: Coordenada radial mínima
            rho_max: Coordenada radial máxima
            packing_factor: Fator de empacotamento na borda (>1 concentra pontos na borda)
        """
        self.n_rho = n_rho
        self.n_theta = n_theta
        self.packing_factor = packing_factor
        
        # Grades 1D
        if packing_factor == 1.0:
            self.rho = np.linspace(rho_min, rho_max, n_rho)
        else:
            # Grade adaptativa: concentra pontos perto de rho_max
            # x vai de 0 a 1 uniformemente
            x = np.linspace(0, 1, n_rho)
            # Transformação: rho = rho_min + (rho_max - rho_min) * (1 - (1-x)^packing_factor)
            self.rho = rho_min + (rho_max - rho_min) * (1 - (1 - x)**packing_factor)
            
        self.theta = np.linspace(0, 2*np.pi, n_theta, endpoint=False)
        
        # Espaçamentos (médios para drho, exato para dtheta)
        self.drho = (rho_max - rho_min) / (n_rho - 1) if n_rho > 1 else 1.0
        self.dtheta = 2 * np.pi / n_theta if n_theta > 1 else 2*np.pi
        
        # Grades 2D (meshgrid)
        self.rho_2d, self.theta_2d = np.meshgrid(self.rho, self.theta, indexing='ij')
    
    def get_index(self, rho_val: float, theta_val: float) -> Tuple[int, int]:
        """
        Encontra os índices (i, j) mais próximos de (ρ, θ).
        
        Args:
            rho_val: Valor de ρ
            theta_val: Valor de θ
            
        Returns:
            Tupla (i_rho, i_theta)
        """
        i_rho = np.argmin(np.abs(self.rho - rho_val))
        
        # Normalizar theta para [0, 2π]
        theta_norm = theta_val % (2*np.pi)
        i_theta = np.argmin(np.abs(self.theta - theta_norm))
        
        return i_rho, i_theta
    
    def interpolate(self, field: np.ndarray, rho_val: float, theta_val: float) -> float:
        """
        Interpola um campo 2D em (ρ, θ).
        
        Args:
            field: Campo 2D [n_rho, n_theta]
            rho_val: Valor de ρ
            theta_val: Valor de θ
            
        Returns:
            Valor interpolado
        """
        from scipy.interpolate import RectBivariateSpline
        
        # Criar interpolador
        interp = RectBivariateSpline(self.rho, self.theta, field, kx=1, ky=1)
        
        # Normalizar theta
        theta_norm = theta_val % (2*np.pi)
        
        # Interpolar
        value = interp(rho_val, theta_norm)[0, 0]
        
        return value


if __name__ == "__main__":
    # Teste do módulo
    print("=" * 80)
    print("TESTE DO MÓDULO TokamakGeometry2D")
    print("=" * 80)
    
    # Criar geometria
    geom = TokamakGeometry2D()
    
    print("\nParâmetros geométricos:")
    print(f"  R₀ = {geom.R0:.2f} m")
    print(f"  a = {geom.a:.2f} m")
    print(f"  κ = {geom.kappa:.2f}")
    print(f"  δ = {geom.delta:.2f}")
    print(f"  ε = {geom.epsilon:.3f}")
    print(f"  Volume = {geom.volume:.1f} m³")
    
    # Criar grade
    grid = Grid2D(n_rho=100, n_theta=64)
    
    print(f"\nGrade computacional:")
    print(f"  N_ρ = {grid.n_rho}")
    print(f"  N_θ = {grid.n_theta}")
    print(f"  Δρ = {grid.drho:.4f}")
    print(f"  Δθ = {grid.dtheta:.4f} rad")
    print(f"  Total de pontos = {grid.n_rho * grid.n_theta}")
    
    # Calcular coordenadas cartesianas
    R, Z = geom.compute_RZ(grid.rho_2d, grid.theta_2d)
    
    print(f"\nCoordenadas cartesianas:")
    print(f"  R_min = {R.min():.2f} m")
    print(f"  R_max = {R.max():.2f} m")
    print(f"  Z_min = {Z.min():.2f} m")
    print(f"  Z_max = {Z.max():.2f} m")
    
    # Calcular Jacobiano
    J = geom.compute_jacobian(grid.rho_2d, grid.theta_2d)
    
    print(f"\nJacobiano:")
    print(f"  J_min = {J.min():.3f}")
    print(f"  J_max = {J.max():.3f}")
    print(f"  J_mean = {J.mean():.3f}")
    
    # Calcular volume
    dV = geom.compute_volume_element(grid.rho_2d, grid.theta_2d)
    V_total = np.sum(dV) * grid.drho * grid.dtheta
    
    print(f"\nVolume calculado:")
    print(f"  V_total = {V_total:.1f} m³")
    print(f"  V_analítico = {geom.volume:.1f} m³")
    print(f"  Erro = {abs(V_total - geom.volume)/geom.volume * 100:.2f}%")
    
    # Calcular q-profile
    Ip = 15.0  # MA
    q_profile = geom.compute_safety_factor(grid.rho, Ip)
    
    print(f"\nPerfil de q:")
    print(f"  q(0) = {q_profile[0]:.2f}")
    print(f"  q(0.5) = {q_profile[grid.n_rho//2]:.2f}")
    print(f"  q₉₅ = {q_profile[int(0.95*grid.n_rho)]:.2f}")
    
    # Calcular shear magnético
    s_profile = geom.compute_magnetic_shear(grid.rho, Ip)
    
    print(f"\nShear magnético:")
    print(f"  s(0) = {s_profile[0]:.2f}")
    print(f"  s(0.5) = {s_profile[grid.n_rho//2]:.2f}")
    print(f"  s(1) = {s_profile[-1]:.2f}")
    
    # Calcular comprimento poloidal
    L_pol_center = geom.compute_poloidal_circumference(0.0)
    L_pol_edge = geom.compute_poloidal_circumference(1.0)
    
    print(f"\nComprimento poloidal:")
    print(f"  L_pol(ρ=0) = {L_pol_center:.2f} m")
    print(f"  L_pol(ρ=1) = {L_pol_edge:.2f} m")
    
    print("\n" + "=" * 80)
