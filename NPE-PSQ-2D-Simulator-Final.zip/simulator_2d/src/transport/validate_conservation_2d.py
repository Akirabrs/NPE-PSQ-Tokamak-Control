"""
Validação de Conservação de Energia 2D (Versão Corrigida)

Verifica se dW/dt = P_in - P_loss com alta precisão.
"""

import numpy as np
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D
from geometry.differential_operators_2d import DifferentialOperators2D
from transport.solver_adi_2d import SolverADI2D
from plasma_state_2d import PlasmaState2D

def validate():
    print("=" * 80)
    print("VALIDAÇÃO DE CONSERVAÇÃO DE ENERGIA 2D")
    print("=" * 80)
    
    geom = TokamakGeometry2D()
    grid = Grid2D(n_rho=50, n_theta=32)
    ops = DifferentialOperators2D(geom, grid)
    solver = SolverADI2D(geom, grid, ops)
    state = PlasmaState2D(geom, grid)
    state.initialize_profiles(T_e_center=5.0, n_e_center=5.0)
    
    dt = 0.001
    chi = np.ones_like(state.T_e) * 1.0 # 1 m²/s
    source = np.ones_like(state.T_e) * 10.0 # 10 MW/m³
    
    # 1. Energia Inicial (Soma direta para consistência com o solver)
    vol_element = ops.R * ops.J * grid.drho * grid.dtheta
    W_start = np.sum(1.5 * state.n_e * state.T_e * vol_element) * 0.01602
    
    # 2. Calcular Perdas Teóricas por Transporte
    diff_term = ops.laplacian_diffusion(state.T_e, chi * state.n_e)
    P_loss_diff = -np.sum(diff_term * vol_element) * 1.5 * 0.01602
    
    # 3. Potência de Aquecimento Total
    P_heat = np.sum(source * vol_element) # MW
    
    # 4. Evolução por um passo
    state.T_e = solver.step(state.T_e, state.n_e, chi, source, dt)
    
    # 5. Energia Final
    W_end = np.sum(1.5 * state.n_e * state.T_e * vol_element) * 0.01602
    
    # 6. Balanço
    dW_dt_observed = (W_end - W_start) / dt
    dW_dt_expected = P_heat - P_loss_diff
    
    print(f"P_heat: {P_heat:.4f} MW")
    print(f"P_loss (transporte): {P_loss_diff:.4f} MW")
    print(f"dW/dt esperado: {dW_dt_expected:.4f} MW")
    print(f"dW/dt observado: {dW_dt_observed:.4f} MW")
    
    error = abs(dW_dt_observed - dW_dt_expected) / (abs(dW_dt_expected) + 1e-10) * 100
    print(f"Erro de Conservação: {error:.4f}%")
    
    if error < 1.0:
        print("\nCONSERVAÇÃO DE ENERGIA VALIDADA! ✅")
    else:
        print("\nERRO DE CONSERVAÇÃO ACIMA DO LIMITE! ❌")
    
    print("=" * 80)

if __name__ == "__main__":
    validate()
