"""
Solver ADI 2D para o Simulador NPE-PSQ (Versão Final Corrigida)

Este módulo implementa o método Alternating Direction Implicit (ADI)
para resolver as equações de transporte 2D em geometria toroidal.
"""

import numpy as np
import sys
sys.path.append('..')

from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D
from geometry.differential_operators_2d import DifferentialOperators2D


class SolverADI2D:
    """
    Solver para as equações de transporte 2D usando o método ADI.
    Resolve: ∂f/∂t = (1/capacity) * [ (1/n) ∇·(n χ ∇f) + S_conv ]
    """
    
    def __init__(self, 
                 geometry: TokamakGeometry2D, 
                 grid: Grid2D,
                 operators: DifferentialOperators2D):
        self.geometry = geometry
        self.grid = grid
        self.ops = operators
        
        # Pré-calcular termos métricos
        self.R = self.ops.R
        self.J = self.ops.J
        self.g_inv_rho_rho = self.ops.g_inv_rho_rho
        self.g_inv_theta_theta = self.ops.g_inv_theta_theta
        
    def step(self, 
             field: np.ndarray, 
             density: np.ndarray,
             chi: np.ndarray, 
             source: np.ndarray, 
             dt: float,
             f_edge: float = 0.01,
             is_density: bool = False) -> np.ndarray:
        
        n_rho = self.grid.n_rho
        n_theta = self.grid.n_theta
        drho = self.grid.drho
        dtheta = self.grid.dtheta
        capacity = 1.0 if is_density else 1.5
        
        # Conversão de unidades: MW/m³ -> keV/s
        # e_conv = 0.01602 (MJ per 10^20 m^-3 * keV)
        source_conv = source / (density * 0.01602)
        
        # --- SUB-PASSO 1: Direção Radial (Implícito em ρ) ---
        # f* - f^n = (dt/2) * [ L_rho(f*) + L_theta(f^n) + S ]
        
        # Termo explícito poloidal L_theta(f^n)
        # L_theta = (1/n RJ) ∂/∂θ (n R J χ g^θθ ∂f/∂θ)
        grad_f_theta = np.gradient(field, dtheta, axis=1)
        flux_theta = density * self.R * self.J * chi * self.g_inv_theta_theta * grad_f_theta
        L_theta_f = (1.0 / (density * self.R * self.J + 1e-10)) * np.gradient(flux_theta, dtheta, axis=1)
        
        # Lado direito para o passo radial
        rhs_rho = field + (dt / 2.0) * (L_theta_f / capacity + source_conv / capacity)
        
        field_half = np.zeros_like(field)
        for j in range(n_theta):
            # Coeficientes para ∂/∂ρ (coeff_rho ∂f/∂ρ)
            coeff_rho = density[:, j] * self.R[:, j] * self.J[:, j] * chi[:, j] * self.g_inv_rho_rho[:, j]
            
            a = np.zeros(n_rho)
            b = np.zeros(n_rho)
            c = np.zeros(n_rho)
            d = rhs_rho[:, j].copy()
            
            for i in range(1, n_rho - 1):
                # Fator local: dt / (2 * capacity * n * R * J)
                factor = dt / (2.0 * capacity * density[i, j] * self.R[i, j] * self.J[i, j] + 1e-10)
                
                val_plus = (coeff_rho[i] + coeff_rho[i+1]) / 2.0
                val_minus = (coeff_rho[i] + coeff_rho[i-1]) / 2.0
                
                a[i] = -factor * val_minus / drho**2
                c[i] = -factor * val_plus / drho**2
                b[i] = 1.0 + (factor * val_plus / drho**2 + factor * val_minus / drho**2)
            
            # Condições de contorno radiais
            b[0] = 1.0; c[0] = -1.0; d[0] = 0.0 # Simetria
            a[-1] = 0.0; b[-1] = 1.0; d[-1] = f_edge # Borda
            
            field_half[:, j] = self._thomas_algorithm(a, b, c, d)
            
        # --- SUB-PASSO 2: Direção Poloidal (Implícito em θ) ---
        # f^(n+1) - f* = (dt/2) * [ L_rho(f*) + L_theta(f^(n+1)) + S ]
        
        # Termo explícito radial L_rho(f*)
        grad_f_rho = np.gradient(field_half, drho, axis=0)
        flux_rho = density * self.R * self.J * chi * self.g_inv_rho_rho * grad_f_rho
        L_rho_f = (1.0 / (density * self.R * self.J + 1e-10)) * np.gradient(flux_rho, drho, axis=0)
        
        # Lado direito para o passo poloidal
        rhs_theta = field_half + (dt / 2.0) * (L_rho_f / capacity + source_conv / capacity)
        
        field_new = np.zeros_like(field)
        for i in range(n_rho):
            coeff_theta = density[i, :] * self.R[i, :] * self.J[i, :] * chi[i, :] * self.g_inv_theta_theta[i, :]
            
            a = np.zeros(n_theta)
            b = np.zeros(n_theta)
            c = np.zeros(n_theta)
            d = rhs_theta[i, :].copy()
            
            for j in range(n_theta):
                factor = dt / (2.0 * capacity * density[i, j] * self.R[i, j] * self.J[i, j] + 1e-10)
                
                jp = (j + 1) % n_theta
                jm = (j - 1) % n_theta
                
                val_plus = (coeff_theta[j] + coeff_theta[jp]) / 2.0
                val_minus = (coeff_theta[j] + coeff_theta[jm]) / 2.0
                
                a[j] = -factor * val_minus / dtheta**2
                c[j] = -factor * val_plus / dtheta**2
                b[j] = 1.0 + (factor * val_plus / dtheta**2 + factor * val_minus / dtheta**2)
            
            field_new[i, :] = self._cyclic_thomas_algorithm(a, b, c, d)
            
        return field_new

    def _thomas_algorithm(self, a, b, c, d):
        n = len(d)
        cp = np.zeros(n); dp = np.zeros(n); x = np.zeros(n)
        cp[0] = c[0] / b[0]; dp[0] = d[0] / b[0]
        for i in range(1, n):
            m = b[i] - a[i] * cp[i-1]
            if i < n - 1: cp[i] = c[i] / m
            dp[i] = (d[i] - a[i] * dp[i-1]) / m
        x[n-1] = dp[n-1]
        for i in range(n-2, -1, -1): x[i] = dp[i] - cp[i] * x[i+1]
        return x

    def _cyclic_thomas_algorithm(self, a, b, c, d):
        n = len(d)
        # Algoritmo de Sherman-Morrison para sistemas cíclicos
        x_0 = self._thomas_algorithm(a, b, c, d)
        u = np.zeros(n); u[0] = -a[0]; u[-1] = -c[-1]
        z = self._thomas_algorithm(a, b, c, u)
        fact = (x_0[0] + x_0[-1]) / (1.0 + z[0] + z[-1])
        return x_0 - fact * z
