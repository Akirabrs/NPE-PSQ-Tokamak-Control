"""
Teste de Aquecimento Puro para o Solver 2D

Verifica se o solver 2D conserva energia e responde corretamente
aos termos fonte sem perdas por transporte.
"""

import numpy as np
import sys
sys.path.append('..')

from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D
from geometry.differential_operators_2d import DifferentialOperators2D
from transport.solver_adi_2d import SolverADI2D


def test_heating():
    print("=" * 80)
    print("TESTE DE AQUECIMENTO PURO 2D")
    print("=" * 80)
    
    geom = TokamakGeometry2D()
    grid = Grid2D(n_rho=50, n_theta=32)
    ops = DifferentialOperators2D(geom, grid)
    solver = SolverADI2D(geom, grid, ops)
    
    # Estado inicial frio
    T_e = np.ones((grid.n_rho, grid.n_theta)) * 0.1
    density = np.ones_like(T_e) * 5.0
    
    # Transporte desligado
    chi = np.zeros_like(T_e)
    
    # Fonte de aquecimento uniforme: 1 MW/m³
    # Q [MW/m³] -> converter para unidades do solver
    # No solver: ∂T/∂t = Q / (1.5 * n_e)
    source = np.ones_like(T_e) * 1.0
    
    print(f"Estado inicial: T_e_mean = {T_e.mean():.4f} keV")
    
    # Simular 100 ms
    dt = 0.001
    n_steps = 100
    
    for step in range(n_steps):
        T_e = solver.step(T_e, density, chi, source, dt)
        
        if (step + 1) % 20 == 0:
            print(f"Passo {step+1:3d}: T_e_mean = {T_e.mean():.4f} keV")
            
    # Taxa de aquecimento teórica:
    # dT/dt = Q / (1.5 * n_e * e)
    # e = 1.602e-19 J/eV = 1.602e-16 J/keV
    # n_e = 5.0e20 m^-3
    # Q = 1.0e6 W/m^3
    # dT/dt = 1.0e6 / (1.5 * 5.0e20 * 1.602e-16) = 1.0e6 / 120150 ≈ 8.32 keV/s
    
    expected_dT = 8.32 * (dt * n_steps)
    actual_dT = T_e.mean() - 0.1
    
    print(f"\nResultados após {dt * n_steps:.3f} s:")
    print(f"  ΔT esperado: {expected_dT:.4f} keV")
    print(f"  ΔT observado: {actual_dT:.4f} keV")
    print(f"  Erro: {abs(actual_dT - expected_dT)/expected_dT * 100:.2f}%")
    
    print("\n" + "=" * 80)


if __name__ == "__main__":
    test_heating()
