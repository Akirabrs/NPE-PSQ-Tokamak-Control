"""
Controle de Posição Vertical 2D para o Simulador NPE-PSQ

Este módulo implementa a dinâmica da instabilidade vertical e o
controlador de feedback para estabilização da posição do plasma.
"""

import numpy as np
from dataclasses import dataclass
from typing import Dict, Tuple
import sys
sys.path.append('..')

from plasma_state_2d import PlasmaState2D


@dataclass
class VerticalDynamicsConfig:
    """Configuração da dinâmica vertical."""
    gamma_v: float = 50.0     # Taxa de crescimento reduzida para teste [s^-1]
    mass_eff: float = 1.0     # Massa efetiva do plasma (normalizada)
    damping: float = 50.0     # Amortecimento passivo aumentado (efeito da parede)
    z_target: float = 0.0     # Posição vertical alvo [m]


class VerticalController2D:
    """
    Controlador de posição vertical (Z).
    Estabiliza a instabilidade vertical inerente a plasmas alongados.
    """
    
    def __init__(self, config: VerticalDynamicsConfig = None):
        self.config = config or VerticalDynamicsConfig()
        
        # Ganhos do PID sintonizados para estabilidade robusta
        self.Kp = 8000.0
        self.Ki = 200.0
        self.Kd = 1200.0
        
        self.integral_error = 0.0
        self.prev_error = 0.0
        
    def compute_control_force(self, z_pos: float, z_vel: float, dt: float) -> float:
        """
        Calcula a força de controle vertical usando PID.
        
        Args:
            z_pos: Posição vertical atual [m]
            z_vel: Velocidade vertical atual [m/s]
            dt: Passo de tempo [s]
            
        Returns:
            Força de controle F_z
        """
        error = self.config.z_target - z_pos
        
        # PID
        self.integral_error += error * dt
        derivative_error = (error - self.prev_error) / (dt + 1e-10)
        
        f_control = self.Kp * error + self.Ki * self.integral_error + self.Kd * derivative_error
        
        # Limite de força (Saturação)
        f_max = 50000.0
        f_control = np.clip(f_control, -f_max, f_max)
        
        self.prev_error = error
        return f_control
    
    def update_dynamics(self, state: PlasmaState2D, f_control: float, dt: float):
        """
        Atualiza a posição e velocidade vertical do plasma.
        
        M d²Z/dt² = M γ_v² Z - D dZ/dt + F_control
        
        Args:
            state: Estado do plasma
            f_control: Força de controle aplicada
            dt: Passo de tempo
        """
        # Aceleração da instabilidade vertical + amortecimento + controle
        z_accel = (self.config.gamma_v**2 * state.Z_pos) - \
                  (self.config.damping * state.Z_vel) + \
                  (f_control / self.config.mass_eff)
        
        # Integração (Euler-Cromer para estabilidade)
        state.Z_vel += z_accel * dt
        state.Z_pos += state.Z_vel * dt
        
        # Limites físicos (borda da câmara)
        z_limit = 1.5 # metros
        if abs(state.Z_pos) > z_limit:
            state.Z_pos = np.sign(state.Z_pos) * z_limit
            state.Z_vel = 0.0


class Diagnostics2D:
    """
    Extrai diagnósticos escalares e perfis médios do estado 2D.
    """
    
    @staticmethod
    def get_control_signals(state: PlasmaState2D) -> Dict[str, float]:
        """
        Retorna os sinais necessários para o controlador NPE-PSQ.
        """
        energy = state.compute_energy_content()
        beta = state.compute_beta()
        
        # Médias volumétricas
        T_e_avg = state.compute_volume_average(state.T_e)
        n_e_avg = state.compute_volume_average(state.n_e)
        
        # Assimetrias
        asymm = state.compute_asymmetries()
        
        return {
            'time': state.time,
            'T_e_avg': T_e_avg,
            'n_e_avg': n_e_avg,
            'W_total': energy['W_total'],
            'beta_N': beta['beta_N'],
            'z_pos': state.Z_pos,
            'z_vel': state.Z_vel,
            'A_IO': asymm['A_IO_Te'].mean() # Assimetria in-out média
        }


if __name__ == "__main__":
    # Teste do controle vertical
    print("=" * 80)
    print("TESTE DE CONTROLE VERTICAL 2D")
    print("=" * 80)
    
    from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D
    
    geom = TokamakGeometry2D()
    grid = Grid2D(n_rho=20, n_theta=16)
    state = PlasmaState2D(geom, grid)
    
    # Perturbação inicial
    state.z_pos = 0.01 # 1 cm de deslocamento
    state.z_vel = 0.0
    
    controller = VerticalController2D()
    
    print(f"{'Tempo [s]':<10} {'Z [mm]':<10} {'Vz [m/s]':<10} {'F_control':<10}")
    print("-" * 50)
    
    dt = 0.001
    for i in range(100):
        f_z = controller.compute_control_force(state.z_pos, state.z_vel, dt)
        controller.update_dynamics(state, f_z, dt)
        
        if i % 10 == 0:
            print(f"{i*dt:<10.3f} {state.z_pos*1000:<10.2f} {state.z_vel:<10.3f} {f_z:<10.1f}")
            
    print("-" * 50)
    print(f"Z final: {state.z_pos*1000:.4f} mm")
    
    if abs(state.z_pos) < 0.001:
        print("\nCONTROLE VERTICAL ESTABILIZADO! ✅")
    else:
        print("\nFALHA NA ESTABILIZAÇÃO! ❌")
        
    print("\n" + "=" * 80)
