"""
Estado do Plasma 2D para o Simulador NPE-PSQ

Este módulo define a classe PlasmaState2D que armazena os perfis 2D
de temperatura, densidade e outras quantidades do plasma.
"""

import numpy as np
from typing import Dict, Tuple
import sys
sys.path.append('geometry')

from geometry.tokamak_geometry_2d import TokamakGeometry2D, Grid2D


class PlasmaState2D:
    """
    Estado do plasma com perfis 2D (ρ, θ).
    
    Armazena:
    - Temperatura eletrônica T_e(ρ, θ)
    - Temperatura iônica T_i(ρ, θ)
    - Densidade eletrônica n_e(ρ, θ)
    - Corrente de plasma I_p
    - Posição vertical Z
    """
    
    def __init__(self, 
                 geometry: TokamakGeometry2D,
                 grid: Grid2D):
        """
        Inicializa o estado do plasma 2D.
        
        Args:
            geometry: Geometria do tokamak
            grid: Grade computacional 2D
        """
        self.geometry = geometry
        self.grid = grid
        
        # Perfis 2D [n_rho, n_theta]
        self.T_e = np.zeros((grid.n_rho, grid.n_theta))  # [keV]
        self.T_i = np.zeros((grid.n_rho, grid.n_theta))  # [keV]
        self.n_e = np.zeros((grid.n_rho, grid.n_theta))  # [10²⁰ m⁻³]
        
        # Quantidades globais
        self.Ip = 0.0      # Corrente de plasma [MA]
        self.Z_pos = 0.0   # Posição vertical [m]
        self.Z_vel = 0.0   # Velocidade vertical [m/s]
        
        # Tempo atual
        self.time = 0.0
        
        # Geometria pré-calculada
        self._compute_geometry()
    
    def _compute_geometry(self):
        """Calcula quantidades geométricas."""
        
        # Coordenadas cartesianas
        self.R, self.Z = self.geometry.compute_RZ(
            self.grid.rho_2d, self.grid.theta_2d
        )
        
        # Jacobiano
        self.J = self.geometry.compute_jacobian(
            self.grid.rho_2d, self.grid.theta_2d
        )
        
        # Elemento de volume
        self.dV = self.geometry.compute_volume_element(
            self.grid.rho_2d, self.grid.theta_2d
        )
    
    def initialize_profiles(self,
                           T_e_center: float = 1.0,
                           T_i_center: float = 1.0,
                           n_e_center: float = 5.0,
                           profile_type: str = "parabolic",
                           exponent: float = 2.0,
                           asymmetry: float = 0.0):
        """
        Inicializa os perfis 2D.
        
        Args:
            T_e_center: Temperatura eletrônica central [keV]
            T_i_center: Temperatura iônica central [keV]
            n_e_center: Densidade eletrônica central [10²⁰ m⁻³]
            profile_type: Tipo de perfil radial ("parabolic", "gaussian")
            exponent: Expoente para perfil parabólico
            asymmetry: Assimetria poloidal (0 = simétrico, 1 = máxima)
        """
        
        # Perfil radial base
        if profile_type == "parabolic":
            radial_shape = (1 - self.grid.rho_2d**exponent)
        elif profile_type == "gaussian":
            sigma = 0.5
            radial_shape = np.exp(-self.grid.rho_2d**2 / (2*sigma**2))
        else:
            radial_shape = np.ones_like(self.grid.rho_2d)
        
        # Assimetria poloidal (in-out)
        # Maior temperatura no lado externo (θ=0) devido ao campo mais fraco
        poloidal_factor = 1 + asymmetry * 0.2 * np.cos(self.grid.theta_2d)
        
        # Perfis 2D
        self.T_e = T_e_center * radial_shape * poloidal_factor
        self.T_i = T_i_center * radial_shape * poloidal_factor
        self.n_e = n_e_center * radial_shape
        
        # Garantir valores mínimos
        self.T_e = np.maximum(self.T_e, 0.01)
        self.T_i = np.maximum(self.T_i, 0.01)
        self.n_e = np.maximum(self.n_e, 0.01)
    
    def compute_poloidal_average(self, field: np.ndarray) -> np.ndarray:
        """
        Calcula a média poloidal de um campo 2D.
        
        ⟨f⟩_θ(ρ) = (1/2π) ∫ f(ρ,θ) dθ
        
        Args:
            field: Campo 2D [n_rho, n_theta]
            
        Returns:
            Perfil radial médio [n_rho]
        """
        # Integração usando trapézio
        avg_profile = np.trapezoid(field, self.grid.theta, axis=1) / (2*np.pi)
        
        return avg_profile
    
    def compute_volume_average(self, field: np.ndarray) -> float:
        """
        Calcula a média volumétrica de um campo 2D.
        
        ⟨f⟩_V = ∫∫ f(ρ,θ) dV / ∫∫ dV
        
        Args:
            field: Campo 2D [n_rho, n_theta]
            
        Returns:
            Média volumétrica (escalar)
        """
        # Integração ponderada pelo volume
        numerator = np.trapezoid(
            np.trapezoid(field * self.dV, self.grid.theta, axis=1),
            self.grid.rho
        )
        
        denominator = np.trapezoid(
            np.trapezoid(self.dV, self.grid.theta, axis=1),
            self.grid.rho
        )
        
        return numerator / denominator
    
    def compute_energy_content(self) -> Dict[str, float]:
        """
        Calcula o conteúdo de energia do plasma.
        
        W = (3/2) ∫∫ n T dV
        
        Returns:
            Dicionário com W_e, W_i, W_total [MJ]
        """
        # Conversão: keV × 10²⁰ m⁻³ × m³ → MJ
        # e_conv = 1.602e-19 J/eV * 1000 eV/keV * 10^20 m^-3 / 10^6 (MJ)
        # e_conv = 0.01602
        conversion = 0.01602
        
        # Integrando (3/2 n T)
        # Nota: Usamos np.sum com o elemento de volume para consistência com o solver
        vol_element = self.geometry.compute_volume_element(self.grid.rho_2d, self.grid.theta_2d) * \
                      2 * np.pi * self.grid.drho * self.grid.dtheta
        
        # W = ∫ (3/2) n T dV
        # n_e = n_i (plasma quasineutro)
        W_e = np.sum(1.5 * self.n_e * self.T_e * vol_element) * conversion
        W_i = np.sum(1.5 * self.n_e * self.T_i * vol_element) * conversion
        
        return {
            'W_e': W_e,
            'W_i': W_i,
            'W_total': W_e + W_i
        }
    
    def compute_asymmetries(self) -> Dict[str, np.ndarray]:
        """
        Calcula as assimetrias poloidais.
        
        Returns:
            Dicionário com perfis de assimetria
        """
        # Índices poloidais
        i_out = 0                          # θ = 0 (lado externo)
        i_in = self.grid.n_theta // 2      # θ = π (lado interno)
        i_top = self.grid.n_theta // 4     # θ = π/2 (topo)
        i_bot = 3 * self.grid.n_theta // 4 # θ = 3π/2 (fundo)
        
        # Assimetria in-out
        A_IO_Te = (self.T_e[:, i_out] - self.T_e[:, i_in]) / \
                  (self.T_e[:, i_out] + self.T_e[:, i_in] + 1e-10)
        
        # Assimetria up-down
        A_UD_Te = (self.T_e[:, i_top] - self.T_e[:, i_bot]) / \
                  (self.T_e[:, i_top] + self.T_e[:, i_bot] + 1e-10)
        
        return {
            'A_IO_Te': A_IO_Te,
            'A_UD_Te': A_UD_Te
        }
    
    def compute_pressure_profile(self) -> np.ndarray:
        """
        Calcula o perfil de pressão 2D.
        
        p(ρ,θ) = n_e (T_e + T_i) × e
        
        Returns:
            Perfil de pressão 2D [Pa]
        """
        # Conversão: 10²⁰ m⁻³ × keV → Pa
        conversion = 1.602e4
        
        pressure = self.n_e * (self.T_e + self.T_i) * conversion
        
        return pressure
    
    def compute_beta(self) -> Dict[str, float]:
        """
        Calcula os parâmetros beta.
        
        Returns:
            Dicionário com beta, beta_N, beta_p
        """
        # Pressão média
        pressure = self.compute_pressure_profile()
        p_avg = self.compute_volume_average(pressure)
        
        # Beta
        B0_sq = self.geometry.B0**2
        mu_0 = 4 * np.pi * 1e-7
        beta = 2 * mu_0 * p_avg / B0_sq
        
        # Beta normalizado
        if self.Ip > 0:
            beta_N = beta / (self.Ip * 1e6 / (self.geometry.a * self.geometry.B0)) * 100
        else:
            beta_N = 0.0
        
        # Beta poloidal
        q_profile = self.geometry.compute_safety_factor(self.grid.rho, self.Ip)
        q_95 = q_profile[int(0.95 * self.grid.n_rho)]
        
        if self.Ip > 0:
            beta_p = beta * (self.geometry.a * self.geometry.B0) / \
                    (self.Ip * 1e6 * mu_0 * q_95)
        else:
            beta_p = 0.0
        
        return {
            'beta': beta,
            'beta_N': beta_N,
            'beta_p': beta_p
        }
    
    def to_dict(self) -> Dict:
        """Converte o estado para um dicionário."""
        return {
            'time': self.time,
            'T_e': self.T_e.copy(),
            'T_i': self.T_i.copy(),
            'n_e': self.n_e.copy(),
            'Ip': self.Ip,
            'Z_pos': self.Z_pos,
            'Z_vel': self.Z_vel
        }
    
    def from_dict(self, data: Dict):
        """Carrega o estado de um dicionário."""
        self.time = data['time']
        self.T_e = data['T_e'].copy()
        self.T_i = data['T_i'].copy()
        self.n_e = data['n_e'].copy()
        self.Ip = data['Ip']
        self.Z_pos = data['Z_pos']
        self.Z_vel = data['Z_vel']
    
    def copy(self) -> 'PlasmaState2D':
        """Cria uma cópia do estado."""
        new_state = PlasmaState2D(self.geometry, self.grid)
        new_state.from_dict(self.to_dict())
        return new_state
    
    def __repr__(self) -> str:
        """Representação em string."""
        energy = self.compute_energy_content()
        beta = self.compute_beta()
        
        T_e_avg = self.compute_volume_average(self.T_e)
        n_e_avg = self.compute_volume_average(self.n_e)
        
        return (
            f"PlasmaState2D(t={self.time:.3f}s, "
            f"⟨T_e⟩={T_e_avg:.2f}keV, "
            f"⟨n_e⟩={n_e_avg:.2f}×10²⁰m⁻³, "
            f"Ip={self.Ip:.2f}MA, "
            f"W={energy['W_total']:.2f}MJ, "
            f"β_N={beta['beta_N']:.2f})"
        )


if __name__ == "__main__":
    # Teste do módulo
    print("=" * 80)
    print("TESTE DO MÓDULO PlasmaState2D")
    print("=" * 80)
    
    # Criar geometria e grade
    geom = TokamakGeometry2D()
    grid = Grid2D(n_rho=100, n_theta=64)
    
    # Criar estado
    state = PlasmaState2D(geom, grid)
    
    # Inicializar perfis
    state.initialize_profiles(
        T_e_center=10.0,
        T_i_center=10.0,
        n_e_center=10.0,
        profile_type="parabolic",
        asymmetry=0.2  # 20% de assimetria
    )
    state.Ip = 15.0
    
    print("\nEstado inicial:")
    print(state)
    
    # Perfis médios poloidais
    T_e_avg_pol = state.compute_poloidal_average(state.T_e)
    
    print(f"\nPerfis médios poloidais:")
    print(f"  ⟨T_e⟩_θ(ρ=0):   {T_e_avg_pol[0]:.2f} keV")
    print(f"  ⟨T_e⟩_θ(ρ=0.5): {T_e_avg_pol[grid.n_rho//2]:.2f} keV")
    print(f"  ⟨T_e⟩_θ(ρ=1):   {T_e_avg_pol[-1]:.2f} keV")
    
    # Assimetrias
    asymm = state.compute_asymmetries()
    
    print(f"\nAssimetrias:")
    print(f"  A_IO(ρ=0.5) = {asymm['A_IO_Te'][grid.n_rho//2]:.3f}")
    print(f"  A_UD(ρ=0.5) = {asymm['A_UD_Te'][grid.n_rho//2]:.3f}")
    
    # Conteúdo de energia
    energy = state.compute_energy_content()
    
    print(f"\nConteúdo de energia:")
    for key, value in energy.items():
        print(f"  {key} = {value:.2f} MJ")
    
    # Beta
    beta = state.compute_beta()
    
    print(f"\nParâmetros beta:")
    for key, value in beta.items():
        print(f"  {key} = {value:.3f}")
    
    # Verificar valores em pontos específicos
    print(f"\nValores em pontos específicos:")
    print(f"  T_e(ρ=0, θ=0) = {state.T_e[0, 0]:.2f} keV (lado externo)")
    print(f"  T_e(ρ=0, θ=π) = {state.T_e[0, grid.n_theta//2]:.2f} keV (lado interno)")
    print(f"  Razão out/in = {state.T_e[0, 0] / state.T_e[0, grid.n_theta//2]:.3f}")
    
    print("\n" + "=" * 80)
